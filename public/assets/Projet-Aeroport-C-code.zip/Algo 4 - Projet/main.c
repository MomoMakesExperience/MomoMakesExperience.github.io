#include <stdio.h>
#include <stdlib.h>
#include "vols.h"
#include "filePiste.h"
#include "pile.h"

void annulerDerniereAction(PileHistorique *pile, pVol *registre, FilePiste *filePiste) {
    if (pile_vide(*pile)) {
        printf("Aucune action a annuler.\n");
        return;
    }

    pAction derniere = consulterSommet(*pile);
    printf("\nANNULATION DE LA DERNIERE ACTION\n");

    if (derniere->type == AJOUT_VOL) {
        printf("Annulation de l'ajout du vol %s\n", derniere->volConcerne.numVol);
        *registre = supprimerVol(*registre, derniere->volConcerne.numVol, NULL);
        *filePiste = retirerVolFile(*filePiste, derniere->volConcerne.numVol);
    }
    else if (derniere->type == SUPPRESSION_VOL) {
        printf("Annulation de la suppression du vol %s\n", derniere->volConcerne.numVol);
        *registre = insererVolTrie(*registre, derniere->volConcerne);
    }
    else if (derniere->type == DECOLLAGE) {
        printf("Annulation du decollage du vol %s\n", derniere->volConcerne.numVol);
        *filePiste = enfiler(*filePiste, derniere->volConcerne, 0);
    }
    
    *pile = desempilerAction(*pile);
}

int main() {
    pVol registre = NULL;
    FilePiste filePiste = {NULL, NULL, 0};
    PileHistorique pileH = {NULL, 0};

    int choix = -1;
    char numVolRecherche[8];
    Vol v;
    int urgence, sens;

    while (choix != 0) {
        printf("\n================ GESTION DE L'AEROPORT ================\n");
        printf("1. Ajouter un vol au registre\n");
        printf("2. Rechercher un vol\n");
        printf("3. Supprimer un vol\n");
        printf("4. Afficher le registre\n");
        printf("5. Enfiler un vol pret au decollage\n");
        printf("6. Faire decoller le prochain vol\n");
        printf("7. Afficher la file d'attente piste\n");
        printf("8. Annuler la derniere action (Undo)\n");
        printf("9. Afficher l'historique\n");
        printf("0. Quitter\n");
        printf("Votre choix : ");
        scanf("%d", &choix);

        switch (choix) {
            case 1:
                printf("\n--- Ajout d'un nouveau vol ---\n");
                printf("Entrer le numero du vol : "); scanf("%s", v.numVol);
                printf("Vers quel destination : "); scanf("%s", v.destination);
                printf("Entrer heure de depart : "); scanf("%d", &v.heureDepart);
                printf("Nombre total de places : "); scanf("%d", &v.nbPlaces);
                v.placesOccupees = 0;
                v.suiv = v.pred = NULL;

                registre = insererVolTrie(registre, v);
                pileH = empilerAction(pileH, AJOUT_VOL, v);
                printf("Le vol numero %s a ete ajoute !\n", v.numVol);
                break;

            case 2:
                printf("\nEntrer le numero de vol a rechercher : ");
                scanf("%s", numVolRecherche);
                pVol res = rechercherVol(registre, numVolRecherche);
                if (res != NULL) {
                    printf("Vol trouve : %s vers %s a %dh | Places : %d/%d\n",
                           res->numVol, res->destination, res->heureDepart,
                           res->placesOccupees, res->nbPlaces);
                } else {
                    printf("Aucun vol trouve avec ce numero.\n");
                }
                break;

            case 3:
                printf("\nEntrer le numero de vol a supprimer : ");
                scanf("%s", numVolRecherche);
                Vol volSupp;
                pVol aux = registre;
                registre = supprimerVol(registre, numVolRecherche, &volSupp);
                if (aux != registre || rechercherVol(registre, numVolRecherche) == NULL) {
                    filePiste = retirerVolFile(filePiste, numVolRecherche);
                    pileH = empilerAction(pileH, SUPPRESSION_VOL, volSupp);
                    printf("Vol supprime du registre et de la file de piste.\n");
                }
                break;

            case 4:
                printf("\nSens d'affichage : 1 pour Chronologique et 2 pour Inverse : ");
                scanf("%d", &sens);
                if (sens == 2) afficherInverse(registre);
                else afficherChronologique(registre);
                break;

            case 5:
                printf("\nEntrer le numero du vol a mettre en file : ");
                scanf("%s", numVolRecherche);
                pVol volPiste = rechercherVol(registre, numVolRecherche);
                if (volPiste == NULL) {
                    printf("Ce vol n'existe pas\n");
                } else {
                    printf("Le vol est-il urgent ? (1 = Oui, 0 = Non) : ");
                    scanf("%d", &urgence);
                    filePiste = enfiler(filePiste, *volPiste, urgence);
                    printf("Vol place dans la file d'attente.\n");
                }
                break;

            case 6:
                if (file_vide(filePiste)) {
                    printf("Aucun vol en attente sur la piste.\n");
                } else {
                    pMaillonFile prochain = consulterTeteFile(filePiste);
                    printf("\nDECOLLAGE DU VOL %s vers %s\n", prochain->vol.numVol, prochain->vol.destination);
                    pileH = empilerAction(pileH, DECOLLAGE, prochain->vol);
                    filePiste = defiler(filePiste);
                }
                break;

            case 7:
                afficherFile(filePiste);
                break;

            case 8:
                annulerDerniereAction(&pileH, &registre, &filePiste);
                break;

            case 9:
                afficherHistorique(pileH);
                break;

            case 0:
                libererRegistre(&registre);
                printf("\nAu revoir !\n");
                break;

            default:
                printf("\nOption invalide.\n");
                break;
        }
    }
    return 0;
}