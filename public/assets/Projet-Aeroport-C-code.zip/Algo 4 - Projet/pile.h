#ifndef PILE_H
#define PILE_H

#include "vols.h"

typedef enum { AJOUT_VOL, SUPPRESSION_VOL, DECOLLAGE } TypeAction;

typedef struct action {
    TypeAction type;
    Vol volConcerne;
    struct action *suiv;
} Action;

typedef Action *pAction;

typedef struct {
    pAction sommet;
    int taille;
} PileHistorique;

pAction creer_maillon_action(TypeAction type, Vol v);
int pile_vide(PileHistorique pile);
pAction consulterSommet(PileHistorique pile);
PileHistorique empilerAction(PileHistorique pile, TypeAction type, Vol v);
PileHistorique desempilerAction(PileHistorique pile);
void afficherHistorique(PileHistorique pile);

#endif