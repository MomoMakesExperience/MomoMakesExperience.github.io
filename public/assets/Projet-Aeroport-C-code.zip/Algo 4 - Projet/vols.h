#ifndef VOLS_H
#define VOLS_H

typedef struct vol {
    char numVol[8];
    char destination[30];
    int heureDepart;
    int nbPlaces;
    int placesOccupees;
    struct vol *suiv;
    struct vol *pred;
} Vol;

typedef Vol *pVol;

pVol creerMaillonVol(Vol v);
pVol rechercherVol(pVol tete, char *numVol);
pVol insererVolTrie(pVol tete, Vol v);
pVol saisieVol(int n);
pVol supprimerVol(pVol tete, char *numVol, Vol *volSupprime);
void afficherChronologique(pVol tete);
void afficherInverse(pVol tete);
pVol fusionnerRegistres(pVol l1, pVol l2);
void libererRegistre(pVol *tete);

#endif