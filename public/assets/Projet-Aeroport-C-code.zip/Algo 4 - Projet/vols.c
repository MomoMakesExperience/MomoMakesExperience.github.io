#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "vols.h"

pVol creerMaillonVol(Vol v) {
    pVol maillon = (pVol)malloc(sizeof(Vol));
    strcpy(maillon->numVol, v.numVol);
    strcpy(maillon->destination, v.destination);
    maillon->heureDepart = v.heureDepart;
    maillon->nbPlaces = v.nbPlaces;
    maillon->placesOccupees = v.placesOccupees;
    maillon->suiv = NULL;
    maillon->pred = NULL;
    return maillon;
}

pVol rechercherVol(pVol tete, char *numVol) {
    pVol courant = tete;
    while (courant != NULL) {
        if (strcmp(courant->numVol, numVol) == 0) return courant;
        courant = courant->suiv;
    }
    return NULL;
}

pVol insererVolTrie(pVol tete, Vol v) {
    if (rechercherVol(tete, v.numVol) != NULL) {
        printf("Le vol %s existe deja dans le registre\n", v.numVol);
        return tete;
    }
    pVol nouveau = creerMaillonVol(v);
    if (tete == NULL) return nouveau;

    if (v.heureDepart < tete->heureDepart) {
        nouveau->suiv = tete;
        tete->pred = nouveau;
        return nouveau;
    }

    pVol courant = tete;
    while (courant->suiv != NULL && courant->suiv->heureDepart <= v.heureDepart) {
        courant = courant->suiv;
    }
    nouveau->suiv = courant->suiv;
    nouveau->pred = courant;

    if (courant->suiv != NULL) {
        courant->suiv->pred = nouveau;
    }
    courant->suiv = nouveau;
    return tete;
}

pVol saisieVol(int n) {
    pVol registre = NULL;
    Vol v;
    for (int i = 0; i < n; i++) {
        printf("Vol %d \nNumero de vol : ", i + 1);
        scanf("%s", v.numVol);
        printf("Destination : ");
        scanf("%s", v.destination);
        printf("Heure de depart : ");
        scanf("%d", &v.heureDepart);
        printf("Nombre de places : ");
        scanf("%d", &v.nbPlaces);
        v.placesOccupees = 0;
        v.suiv = v.pred = NULL;
        registre = insererVolTrie(registre, v);
    }
    return registre;
}

pVol supprimerVol(pVol tete, char *numVol, Vol *volSupprime) {
    pVol X = rechercherVol(tete, numVol);
    if (X == NULL) {
        printf("Le vol %s est introuvable\n", numVol);
        return tete;
    }
    if (volSupprime != NULL) *volSupprime = *X;

    if (X->pred != NULL) X->pred->suiv = X->suiv;
    else tete = X->suiv;

    if (X->suiv != NULL) X->suiv->pred = X->pred;

    free(X);
    return tete;
}

void afficherChronologique(pVol tete) {
    if (tete == NULL) {
        printf("Le registre des vols est vide.\n");
        return;
    }
    pVol courant = tete;
    printf("\nListe des vols par ordre chronologique :\n");
    while (courant != NULL) {
        printf("Le vol %s a destination de %s decolle a %d Nb de Places: %d\n",
               courant->numVol, courant->destination, courant->heureDepart,
               courant->nbPlaces);
        courant = courant->suiv;
    }
}

void afficherInverse(pVol tete) {
    if (tete == NULL) {
        printf("Le registre des vols est vide.\n");
        return;
    }
    pVol courant = tete;
    while (courant->suiv != NULL) courant = courant->suiv;

    printf("\nListe des vols par ordre inverse :\n");
    while (courant != NULL) {
        printf("Le %s a destination de %s a %d avec %d de places occupees sur les %d\n",
               courant->numVol, courant->destination, courant->heureDepart,
               courant->placesOccupees, courant->nbPlaces);
        courant = courant->pred;
    }
}

pVol fusionnerRegistres(pVol l1, pVol l2) {
    pVol resultat = NULL;
    pVol courant = l1;
    while (courant != NULL) {
        resultat = insererVolTrie(resultat, *courant);
        courant = courant->suiv;
    }
    courant = l2;
    while (courant != NULL) {
        if (rechercherVol(resultat, courant->numVol) != NULL) {
            printf("Doublon refuse : %s\n", courant->numVol);
        } else {
            resultat = insererVolTrie(resultat, *courant);
        }
        courant = courant->suiv;
    }
    return resultat;
}

void libererRegistre(pVol *tete) {
    pVol courant = *tete;
    pVol suivant;
    while (courant != NULL) {
        suivant = courant->suiv;
        free(courant);
        courant = suivant;
    }
    *tete = NULL;
}