Ce projet en C permet de gerer les opérations de base d'un aeroport :
1. Registre des vols programmés : ajout, recherche, affichage et suppression
2. Gestion de la piste de décollage avec une file d'attente prioritaire (vols urgents).
3. Historique des actions avec gestion des annulations.

ORGANISATION DES FICHIERS:
- vols.h et vols.c           : Gestion du registre des vols (Liste doublement chainee)
- filePiste.h et filePiste.c : Gestion des decollages sur la piste (File)
- pile.h et pile.c           : Gestion de l'historique des actions (Pile)
- main.c                     : Menu principal

Notice

1 - Ajouter un Vol : Tapez 1 pour enregistrer un nouveau vol. Saisissez son numéro, sa destination, son heure (1430 pour 14h30) et son nombre de places.

2 - Rechercher un vol : Tapez 2 puis entrez le numéro du vol pour voir toutes ses informations.

3 - Supprimer un vol : Tapez 3 puis le numéro du vol pour l'annuler et le retirer du registre.

4 - Afficher les vols : Tapez 4 pour afficher la liste de tous les vols (choisissez 1 pour l'ordre des heures ou 2 pour l'ordre inverse).

5 - Mettre un vol en attente de décollage : Tapez 5 et donnez le numéro du vol. Le programme vous demandera si le vol est urgent (1 pour Oui, 0 pour Non). S'il est urgent, il passe prioritaire sur la piste.

6 - Faire décoller un vol : Tapez 6 pour autoriser le décollage du premier avion en attente sur la piste.

7 - Voir la piste : Tapez 7 pour afficher la liste des avions qui attendent sur la piste.

8 - Annuler la dernière action : Tapez 8 si vous avez fait une erreur. Cela annule automatiquement la toute dernière opération (ajout, suppression ou décollage).

9 - Historique : Tapez 9 pour afficher la liste des 10 dernières actions effectuées.

0 - Quitter : Tapez 0 pour fermer le programme.