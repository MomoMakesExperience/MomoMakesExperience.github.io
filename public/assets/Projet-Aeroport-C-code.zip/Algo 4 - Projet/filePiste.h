#ifndef FILEPISTE_H
#define FILEPISTE_H

#include "vols.h"

typedef struct maillonFile {
    Vol vol;
    int urgence;
    struct maillonFile *suiv;
} MaillonFile;

typedef MaillonFile *pMaillonFile;

typedef struct {
    pMaillonFile tete;
    pMaillonFile queue;
    int taille;
} FilePiste;

pMaillonFile creer_maillon_file(Vol v, int urgence);
int file_vide(FilePiste file);
pMaillonFile consulterTeteFile(FilePiste file);
FilePiste enfiler(FilePiste file, Vol v, int urgence);
FilePiste defiler(FilePiste file);
FilePiste retirerVolFile(FilePiste file, char *numVol);
void afficherFile(FilePiste file);

#endif