#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "filePiste.h"

pMaillonFile creer_maillon_file(Vol v, int urgence) {
    pMaillonFile maillon = (pMaillonFile)malloc(sizeof(MaillonFile));
    maillon->vol = v;
    maillon->urgence = urgence;
    maillon->suiv = NULL;
    return maillon;
}

int file_vide(FilePiste file) {
    return (file.taille == 0);
}

pMaillonFile consulterTeteFile(FilePiste file) {
    if (!file_vide(file)) return file.tete;
    return NULL;
}

FilePiste enfiler(FilePiste file, Vol v, int urgence) {
    pMaillonFile maillon = creer_maillon_file(v, urgence);

    if (file_vide(file)) {
        file.tete = file.queue = maillon;
    } else if (urgence == 1) {
        if (file.tete->urgence == 0) {
            maillon->suiv = file.tete;
            file.tete = maillon;
        } else {
            pMaillonFile courant = file.tete;
            while (courant->suiv != NULL && courant->suiv->urgence == 1) {
                courant = courant->suiv;
            }
            maillon->suiv = courant->suiv;
            courant->suiv = maillon;
            if (maillon->suiv == NULL) file.queue = maillon;
        }
    } else {
        (file.queue)->suiv = maillon;
        file.queue = maillon;
    }
    file.taille++;
    return file;
}

FilePiste defiler(FilePiste file) {
    if (!file_vide(file)) {
        pMaillonFile p = file.tete;
        file.tete = (file.tete)->suiv;
        file.taille--;
        free(p);
        if (file.taille == 0) file.queue = NULL;
    }
    return file;
}

FilePiste retirerVolFile(FilePiste file, char *numVol) {
    FilePiste aux;
    aux.tete = aux.queue = NULL;
    aux.taille = 0;

    while (!file_vide(file)) {
        pMaillonFile t = consulterTeteFile(file);
        if (strcmp(t->vol.numVol, numVol) != 0) {
            aux = enfiler(aux, t->vol, t->urgence);
        }
        file = defiler(file);
    }
    return aux;
}

void afficherFile(FilePiste file) {
    pMaillonFile courant = file.tete;
    if (file_vide(file)) {
        printf("La piste est vide.\n");
    } else {
        printf("\nFILE D'ATTENTE DE LA PISTE :\n");
        while (courant != NULL) {
            printf("Vol %s -> %s a %d | Statut: %s\n",
                   courant->vol.numVol, courant->vol.destination, courant->vol.heureDepart,
                   (courant->urgence == 1) ? "URGENCE" : "NON URGENT");
            courant = courant->suiv;
        }
    }
}