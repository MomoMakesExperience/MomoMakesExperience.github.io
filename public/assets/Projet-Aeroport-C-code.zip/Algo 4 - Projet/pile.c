#include <stdio.h>
#include <stdlib.h>
#include "pile.h"

pAction creer_maillon_action(TypeAction type, Vol v) {
    pAction maillon = (pAction)malloc(sizeof(Action));
    maillon->type = type;
    maillon->volConcerne = v;
    maillon->suiv = NULL;
    return maillon;
}

int pile_vide(PileHistorique pile) {
    return (pile.taille == 0);
}

pAction consulterSommet(PileHistorique pile) {
    if (!pile_vide(pile)) return pile.sommet;
    return NULL;
}

static pAction insertionT_pile(pAction l, TypeAction type, Vol v) {
    pAction maillon = creer_maillon_action(type, v);
    maillon->suiv = l;
    return maillon;
}

PileHistorique desempilerAction(PileHistorique pile) {
    if (!pile_vide(pile)) {
        pAction p = pile.sommet;
        pile.sommet = (pile.sommet)->suiv;
        pile.taille--;
        free(p);
    }
    return pile;
}

static PileHistorique empilerActionSimple(PileHistorique pile, TypeAction type, Vol v) {
    pile.sommet = insertionT_pile(pile.sommet, type, v);
    pile.taille++;
    return pile;
}

static PileHistorique supprimerFond(PileHistorique pile) {
    PileHistorique aux;
    aux.sommet = NULL; aux.taille = 0;

    while (pile.taille > 1) {
        pAction s = consulterSommet(pile);
        aux = empilerActionSimple(aux, s->type, s->volConcerne);
        pile = desempilerAction(pile);
    }
    pile = desempilerAction(pile);

    while (!pile_vide(aux)) {
        pAction s = consulterSommet(aux);
        pile = empilerActionSimple(pile, s->type, s->volConcerne);
        aux = desempilerAction(aux);
    }
    return pile;
}

PileHistorique empilerAction(PileHistorique pile, TypeAction type, Vol v) {
    if (pile.taille >= 10) {
        pile = supprimerFond(pile);
    }
    pile = empilerActionSimple(pile, type, v);
    return pile;
}

void afficherHistorique(PileHistorique pile) {
    pAction courant = pile.sommet;
    if (pile_vide(pile)) {
        printf("L'historique est vide.\n");
    } else {
        printf("\nHISTORIQUE DES OPERATIONS :\n");
        while (courant != NULL) {
            printf("Action : ");
            if (courant->type == AJOUT_VOL) printf("AJOUT DE VOL ");
            else if (courant->type == SUPPRESSION_VOL) printf("SUPPRESSION DE VOL ");
            else if (courant->type == DECOLLAGE) printf("DECOLLAGE ");
            printf("-> Vol %s vers %s\n", courant->volConcerne.numVol, courant->volConcerne.destination);
            courant = courant->suiv;
        }
    }
}