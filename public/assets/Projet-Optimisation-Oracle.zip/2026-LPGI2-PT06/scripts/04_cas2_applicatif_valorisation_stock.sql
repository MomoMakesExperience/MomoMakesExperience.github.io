CREATE OR REPLACE PROCEDURE valoriser_stock_naif AS
  v_prix NUMBER;
  v_valeur_totale NUMBER := 0;
BEGIN
  FOR ligne IN (SELECT produit_id, quantite_stock FROM stock) LOOP
    SELECT prix_reference INTO v_prix
    FROM produit
    WHERE produit_id = ligne.produit_id;

    v_valeur_totale := v_valeur_totale + (ligne.quantite_stock * v_prix);
  END LOOP;

  DBMS_OUTPUT.PUT_LINE('Valeur totale du stock : ' || v_valeur_totale);
END;
/

CREATE OR REPLACE PROCEDURE valoriser_stock_optimise AS
  TYPE t_valeur IS TABLE OF NUMBER;
  v_valeurs t_valeur;
  v_valeur_totale NUMBER := 0;
BEGIN
  SELECT s.quantite_stock * p.prix_reference
  BULK COLLECT INTO v_valeurs
  FROM stock s, produit p
  WHERE s.produit_id = p.produit_id;

  FOR i IN 1..v_valeurs.COUNT LOOP
    v_valeur_totale := v_valeur_totale + v_valeurs(i);
  END LOOP;

  DBMS_OUTPUT.PUT_LINE('Valeur totale du stock (optimisée) : ' || v_valeur_totale);
END;
/

SET TIMING ON;
EXEC valoriser_stock_naif;
SET TIMING OFF;

SET TIMING ON;
EXEC valoriser_stock_optimise;
SET TIMING OFF;