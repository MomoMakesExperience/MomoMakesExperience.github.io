SELECT m.nom AS magasin, c.date_vente, SUM(lc.quantite * lc.prix_unitaire) AS total_vente
FROM commande c, ligne_commande lc, magasin m
WHERE c.commande_id = lc.commande_id
  AND c.magasin_id = m.magasin_id
  AND c.magasin_id = 2
  AND c.date_vente BETWEEN DATE '2024-06-01' AND DATE '2024-06-30'
GROUP BY m.nom, c.date_vente
ORDER BY c.date_vente;

BEGIN
  DBMS_STATS.GATHER_SCHEMA_STATS(
    ownname => 'DISTRIPLUS',
    estimate_percent => DBMS_STATS.AUTO_SAMPLE_SIZE
  );
END;
/

DELETE FROM plan_table;
COMMIT;

EXPLAIN PLAN FOR
SELECT m.nom AS magasin, c.date_vente, SUM(lc.quantite * lc.prix_unitaire) AS total_vente
FROM commande c, ligne_commande lc, magasin m
WHERE c.commande_id = lc.commande_id
  AND c.magasin_id = m.magasin_id
  AND c.magasin_id = 2
  AND c.date_vente BETWEEN DATE '2024-06-01' AND DATE '2024-06-30'
GROUP BY m.nom, c.date_vente
ORDER BY c.date_vente;

SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY);

GRANT SELECT_CATALOG_ROLE TO distriplus;
GRANT SELECT ANY DICTIONARY TO distriplus;

SET AUTOTRACE ON;

SELECT m.nom AS magasin, c.date_vente, SUM(lc.quantite * lc.prix_unitaire) AS total_vente
FROM commande c, ligne_commande lc, magasin m
WHERE c.commande_id = lc.commande_id
  AND c.magasin_id = m.magasin_id
  AND c.magasin_id = 2
  AND c.date_vente BETWEEN DATE '2024-06-01' AND DATE '2024-06-30'
GROUP BY m.nom, c.date_vente
ORDER BY c.date_vente;

SET AUTOTRACE OFF;

CREATE INDEX idx_commande_magasin_date ON commande(magasin_id, date_vente);

BEGIN
  DBMS_STATS.GATHER_TABLE_STATS(ownname => 'DISTRIPLUS', tabname => 'COMMANDE', cascade => TRUE);
END;
/

DELETE FROM plan_table;
COMMIT;

EXPLAIN PLAN FOR
SELECT m.nom AS magasin, c.date_vente, SUM(lc.quantite * lc.prix_unitaire) AS total_vente
FROM commande c, ligne_commande lc, magasin m
WHERE c.commande_id = lc.commande_id
  AND c.magasin_id = m.magasin_id
  AND c.magasin_id = 2
  AND c.date_vente BETWEEN DATE '2024-06-01' AND DATE '2024-06-30'
GROUP BY m.nom, c.date_vente
ORDER BY c.date_vente;

SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY);

SET AUTOTRACE ON;

SELECT m.nom AS magasin, c.date_vente, SUM(lc.quantite * lc.prix_unitaire) AS total_vente
FROM commande c, ligne_commande lc, magasin m
WHERE c.commande_id = lc.commande_id
  AND c.magasin_id = m.magasin_id
  AND c.magasin_id = 2
  AND c.date_vente BETWEEN DATE '2024-06-01' AND DATE '2024-06-30'
GROUP BY m.nom, c.date_vente
ORDER BY c.date_vente;

SET AUTOTRACE OFF;