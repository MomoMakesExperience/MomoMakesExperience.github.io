DELETE FROM plan_table;
COMMIT;

EXPLAIN PLAN FOR
SELECT c.magasin_id, SUM(lc.quantite) AS quantite_totale
FROM ligne_commande lc, commande c
WHERE lc.commande_id = c.commande_id
  AND lc.produit_id = 5
GROUP BY c.magasin_id;

SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY);

ALTER TABLE ligne_commande ADD magasin_id NUMBER;

UPDATE ligne_commande lc
SET magasin_id = (
  SELECT c.magasin_id FROM commande c WHERE c.commande_id = lc.commande_id
);
COMMIT;

ALTER TABLE ligne_commande ADD CONSTRAINT fk_ligne_magasin
  FOREIGN KEY (magasin_id) REFERENCES magasin(magasin_id);

BEGIN
  DBMS_STATS.GATHER_TABLE_STATS(ownname => 'DISTRIPLUS', tabname => 'LIGNE_COMMANDE', cascade => TRUE);
END;
/

DELETE FROM plan_table;
COMMIT;

EXPLAIN PLAN FOR
SELECT magasin_id, SUM(quantite) AS quantite_totale
FROM ligne_commande
WHERE produit_id = 5
GROUP BY magasin_id;

SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY);
