BEGIN
  INSERT INTO magasin VALUES (1, 'DistriPlus Plateau', 'Dakar', 'Ouest');
  INSERT INTO magasin VALUES (2, 'DistriPlus Thies', 'Thies', 'Ouest');
  INSERT INTO magasin VALUES (3, 'DistriPlus Saint-Louis', 'Saint-Louis', 'Nord');
  INSERT INTO magasin VALUES (4, 'DistriPlus Kaolack', 'Kaolack', 'Centre');
  INSERT INTO magasin VALUES (5, 'DistriPlus Ziguinchor', 'Ziguinchor', 'Sud');
  COMMIT;
END;
/

DECLARE
  v_villes VARCHAR2(200) := 'Dakar,Thies,Saint-Louis,Kaolack,Ziguinchor,Louga';
BEGIN
  FOR i IN 1..10 LOOP
    INSERT INTO fournisseur (fournisseur_id, nom, ville)
    VALUES (i, 'Fournisseur ' || i,
            REGEXP_SUBSTR(v_villes, '[^,]+', 1, TRUNC(DBMS_RANDOM.VALUE(1,7))));
  END LOOP;
  COMMIT;
END;
/

DECLARE
  v_villes VARCHAR2(200) := 'Dakar,Thies,Saint-Louis,Kaolack,Ziguinchor,Louga';
BEGIN
  FOR i IN 1..200 LOOP
    INSERT INTO client (client_id, nom, ville)
    VALUES (i, 'Client ' || i,
            REGEXP_SUBSTR(v_villes, '[^,]+', 1, TRUNC(DBMS_RANDOM.VALUE(1,7))));
  END LOOP;
  COMMIT;
END;
/

DECLARE
  v_categories VARCHAR2(200) := 'Alimentaire,Boisson,Hygiene,Electromenager,Textile';
BEGIN
  FOR i IN 1..30 LOOP
    INSERT INTO produit (produit_id, nom, categorie, prix_reference, fournisseur_id)
    VALUES (i, 'Produit ' || i,
            REGEXP_SUBSTR(v_categories, '[^,]+', 1, TRUNC(DBMS_RANDOM.VALUE(1,6))),
            ROUND(DBMS_RANDOM.VALUE(1000, 50000), 2),
            TRUNC(DBMS_RANDOM.VALUE(1,11)));
  END LOOP;
  COMMIT;
END;
/

DECLARE
  v_batch_size  NUMBER := 100000;
  v_nb_clients  NUMBER;
BEGIN
  SELECT COUNT(*) INTO v_nb_clients FROM client;

  FOR m IN 1..5 LOOP
    INSERT INTO commande (commande_id, magasin_id, client_id, date_vente, montant_total)
    SELECT (m-1)*v_batch_size + ROWNUM, magasin_id, client_id, date_vente, NULL
    FROM (
      SELECT m AS magasin_id,
             TRUNC(DBMS_RANDOM.VALUE(1, v_nb_clients + 1)) AS client_id,
             DATE '2024-01-01' + TRUNC(DBMS_RANDOM.VALUE(0,730)) AS date_vente
      FROM dual
      CONNECT BY LEVEL <= v_batch_size
      ORDER BY date_vente
    );
    COMMIT;
  END LOOP;
END;
/
SELECT COUNT(*) AS nb_commande FROM commande;

DECLARE
  v_batch_size NUMBER := 100000;
  v_nb_batches NUMBER := 5;
BEGIN
  FOR b IN 0..(v_nb_batches-1) LOOP
    INSERT INTO ligne_commande (ligne_id, commande_id, produit_id, quantite, prix_unitaire)
    SELECT
      (b*v_batch_size*2) + ROWNUM,
      x.commande_id,
      x.produit_id,
      x.quantite,
      p.prix_reference
    FROM (
      SELECT
        c.commande_id,
        TRUNC(DBMS_RANDOM.VALUE(1,31)) AS produit_id,
        TRUNC(DBMS_RANDOM.VALUE(1,11)) AS quantite
      FROM commande c
      CROSS JOIN (SELECT LEVEL AS n FROM dual CONNECT BY LEVEL <= 2)
      WHERE c.commande_id > b*v_batch_size AND c.commande_id <= (b+1)*v_batch_size
    ) x
    JOIN produit p ON p.produit_id = x.produit_id;
    COMMIT;
  END LOOP;
END;
/
SELECT COUNT(*) AS nb_ligne_commande FROM ligne_commande;

INSERT INTO stock (stock_id, magasin_id, produit_id, quantite_stock, date_maj)
SELECT ROWNUM, magasin_id, produit_id,
       TRUNC(DBMS_RANDOM.VALUE(0,500)),
       DATE '2014-01-01' + jour - 1
FROM (
  SELECT m.magasin_id, p.produit_id, j.jour
  FROM (SELECT LEVEL AS magasin_id FROM dual CONNECT BY LEVEL <= 5) m,
       (SELECT LEVEL AS produit_id FROM dual CONNECT BY LEVEL <= 30) p,
       (SELECT LEVEL AS jour FROM dual CONNECT BY LEVEL <= 4000) j
);
COMMIT;
