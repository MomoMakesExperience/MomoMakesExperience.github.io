SET TIMING ON;
SELECT SUM(quantite * prix_unitaire) AS chiffre_affaires
FROM ligne_commande;
SET TIMING OFF;

SET TIMING ON;
SELECT SUM(lc.quantite * p.prix_reference) AS chiffre_affaires
FROM ligne_commande lc, produit p
WHERE lc.produit_id = p.produit_id;
SET TIMING OFF;