CREATE TABLE magasin (
    magasin_id     NUMBER PRIMARY KEY,
    nom            VARCHAR2(100) NOT NULL,
    ville          VARCHAR2(100),
    region         VARCHAR2(50)
);
CREATE TABLE client (
    client_id      NUMBER PRIMARY KEY,
    nom            VARCHAR2(100) NOT NULL,
    ville          VARCHAR2(100)
);
CREATE TABLE fournisseur (
    fournisseur_id NUMBER PRIMARY KEY,
    nom            VARCHAR2(100) NOT NULL,
    ville          VARCHAR2(100)
);
CREATE TABLE produit (
    produit_id     NUMBER PRIMARY KEY,
    nom            VARCHAR2(150) NOT NULL,
    categorie      VARCHAR2(50),
    prix_reference NUMBER(10,2),
    fournisseur_id NUMBER,
CONSTRAINT fk_produit_fournisseur FOREIGN KEY (fournisseur_id)
REFERENCES fournisseur(fournisseur_id)
);
CREATE TABLE commande (
    commande_id    NUMBER PRIMARY KEY,
    magasin_id     NUMBER NOT NULL,
    client_id      NUMBER,
    date_vente     DATE NOT NULL,
    montant_total  NUMBER(10,2),
CONSTRAINT fk_commande_magasin FOREIGN KEY (magasin_id)
REFERENCES magasin(magasin_id),
CONSTRAINT fk_commande_client FOREIGN KEY (client_id)
REFERENCES client(client_id)
);
CREATE TABLE ligne_commande (
    ligne_id       NUMBER PRIMARY KEY,
    commande_id    NUMBER NOT NULL,
    produit_id     NUMBER NOT NULL,
    quantite       NUMBER NOT NULL,
    prix_unitaire  NUMBER(10,2) NOT NULL,
CONSTRAINT fk_ligne_commande FOREIGN KEY (commande_id)
REFERENCES commande(commande_id),
CONSTRAINT fk_ligne_produit FOREIGN KEY (produit_id)
REFERENCES produit(produit_id)
);
CREATE TABLE stock (
    stock_id       NUMBER PRIMARY KEY,
    magasin_id     NUMBER NOT NULL,
    produit_id     NUMBER NOT NULL,
    quantite_stock NUMBER DEFAULT 0,
    date_maj       DATE,
CONSTRAINT fk_stock_magasin FOREIGN KEY (magasin_id)
REFERENCES magasin(magasin_id),
CONSTRAINT fk_stock_produit FOREIGN KEY (produit_id)
REFERENCES produit(produit_id)
);

SELECT table_name FROM user_tables ORDER BY table_name;