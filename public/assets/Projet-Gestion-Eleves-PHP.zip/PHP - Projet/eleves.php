<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>page</title>
    <link rel="stylesheet" href="style2.css">
</head>
<body>
    <div id="tableau">
        <h2>Tous les élèves</h2>

        <table>
            <tr id="entete">
                <th>ID</th>
                <th>Nom</th>
                <th>Mail</th>
                <th>Date de Naissance</th>
                <th>Modifier</th>
                <th>Supprimer</th>
            </tr>
            <?php
                include_once "connexion.php";

                $req = mysqli_query($conn , "SELECT * FROM eleve");
                
                if(mysqli_num_rows($req) == 0){
                    echo "<tr><td colspan='6' id='msg'>Il n'y a pas encore d'eleve ajouté !</td></tr>" ;
                } else {
                    while($row=mysqli_fetch_assoc($req)){
                        ?>
                        <tr>
                            <td><?=htmlspecialchars($row['id_eleve'])?></td>
                            <td><?=htmlspecialchars($row['nom_eleve'])?></td>
                            <td><?=htmlspecialchars($row['mail_eleve'])?></td>
                            <td><?=htmlspecialchars($row['datenaiss_eleve'])?></td>
                           <td><a class="boutons boutonM" href="modifier.php?id=<?=$row['id_eleve']?>">Modifier</a></td>
                           <td><a class="boutons boutonSp" href="supprimer.php?id=<?=$row['id_eleve']?>" onclick="return confirm('Etes vous sur de vouloir supprimer ?');">Supprimer</a></td>
                        </tr>
                        <?php
                    }
                }
            ?>
        </table>
    </div>
</body>
</html>
