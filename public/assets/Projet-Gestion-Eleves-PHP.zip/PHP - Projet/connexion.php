<?php

    $servername = "localhost";     
    $username = "root";            
    $password = "";                
    $dbname = "ecole";    


    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
    die("Echec connexion : " . $conn->connect_error);
    }
    // echo "Connexion réussie !";
?>
