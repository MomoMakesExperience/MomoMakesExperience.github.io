-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : sam. 13 juin 2026 à 11:22
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `ecole`
--

-- --------------------------------------------------------

--
-- Structure de la table `eleve`
--

CREATE TABLE `eleve` (
  `id_eleve` int(11) NOT NULL,
  `nom_eleve` varchar(100) NOT NULL,
  `mail_eleve` varchar(100) NOT NULL,
  `datenaiss_eleve` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `eleve`
--

INSERT INTO `eleve` (`id_eleve`, `nom_eleve`, `mail_eleve`, `datenaiss_eleve`) VALUES
(1, 'Mamadou SECK', 'seckmamadou2506@gmail.com', '2000-06-25'),
(2, 'Fatou Kany FALL', 'kanyfall@gmail.com', '1972-10-18'),
(3, 'Marieme SECK', 'seckmarieme@gmail.com', '2004-10-18'),
(4, 'Awa Barry', 'awabarry@gmail.com', '2004-12-16'),
(5, 'Malick Gueye', 'gueyemalick@yahoo.fr', '1996-06-19'),
(6, 'Youssou NDOUR', 'ndouryoussou@princearts.com', '1975-06-19'),
(7, 'Michael JACKSON', 'Jmichael@hollywood.com', '1962-03-08'),
(8, 'Tony Parker', 'tonyparker@nba.com', '1970-04-10'),
(9, 'Jordan', 'Jordan@nba.com', '1990-07-23'),
(10, 'AKON', 'akon@rocnation.com', '1987-07-23');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `eleve`
--
ALTER TABLE `eleve`
  ADD PRIMARY KEY (`id_eleve`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `eleve`
--
ALTER TABLE `eleve`
  MODIFY `id_eleve` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
