<?php

    if(isset($_POST["envoyer"])){

        if(empty($_POST["nom"])){                  
            echo "Veuillez saisir un nom !";
        } elseif (empty($_POST["mail"]) || !filter_var($_POST["mail"], FILTER_VALIDATE_EMAIL)){     
            echo "Veuillez saisir une adresse mail valide !";
        } elseif (empty($_POST["date"])){
            echo "Veuillez saisir une date !";
        } else { 
            include_once "connexion.php";

            $nom = htmlspecialchars($_POST["nom"]);
            $mail = htmlspecialchars($_POST["mail"]);
            $date = htmlspecialchars($_POST["date"]);

            $req = mysqli_query($conn , "INSERT INTO eleve (id_eleve, nom_eleve, mail_eleve, datenaiss_eleve) 
                                        VALUES (NULL, '$nom', '$mail', '$date')");
            if($req){
                header("location: eleves.php");
            } else {
                echo "eleve non ajouté !" ;
            } 
        }
    } else {
        echo "Veuillez valider le formulaire !";
    }
    
?>
