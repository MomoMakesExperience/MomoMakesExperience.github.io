<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier</title>
    <link rel="stylesheet" href="style3.css">
</head>
<body>
    <?php
        include_once "connexion.php";
        $id = $_GET['id'];
        $req = mysqli_query($conn, "SELECT * FROM eleve WHERE id_eleve = $id");
        $row = mysqli_fetch_assoc($req);
        if(isset($_POST['button'])){
            extract($_POST);
            if(!empty($nom) && !empty($mail) && !empty($date)){
                $req = mysqli_query($conn, "UPDATE eleve SET nom_eleve = '$nom' , mail_eleve = '$mail', datenaiss_eleve = '$date' WHERE id_eleve = $id");
                if($req){  
                    header("location: eleves.php");
                }  else {
                    $message = "eleve non modifié";
                }
            } else {
                $message = "Veuillez remplir tous les champs !";
            }
        }
    ?>
    <div id="formulaire">
        <a href="eleves.php"> Retour </a>
        <p class="boutonA">
            <?php
                if (isset($message)){
                    echo $message;
                }
            ?>
        </p>
        <form method="POST" action="">
            <fieldset>
                <legend>Modifier : <?=$row['nom_eleve']?> </legend>
                                
                <div id="champs">
                    <label for="nom"></label>
                    <input id="nom" type="text" name="nom" value="<?=$row['nom_eleve']?>">
                </div>

                <div id="champs">
                    <label for="mail"></label>
                    <input id="mail" type="email" name="mail" value="<?=$row['mail_eleve']?>">
                </div>

                <div id="champs">
                    <label for="date"></label>
                    <input id="date" type="date" name="date" value="<?=$row['datenaiss_eleve']?>">
                </div>
                                
                <div id="boutonA">
                    <input type="submit" name="button" value="Modifier">
                </div>
            </fieldset>
        </form>
    </div>

</body>
</html>
