<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulaire d'Inscription</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div id="formulaire">
        <form method="POST" action="cible.php">
            <fieldset>
                <legend>Inscription</legend>
                
                <div id="champs">
                    <label for="nom">Nom complet : </label>
                    <input id="nom" type="text" name="nom" placeholder="Entrer votre nom">
                </div>
                
                <div id="champs">
                    <label for="mail">Adresse email : </label>
                    <input id="mail" type="email" name="mail" placeholder="Entrer votre adresse mail">
                </div>

                <div id="champs">
                    <label for="date">Date : </label>
                    <input id="date" type="date" name="date" required>
                </div>
                
                <div id="boutons">
                    <input type="submit" name="envoyer" value="Enregistrer">
                    <input type="reset" value="Effacer">
                </div>
            </fieldset>
        </form>
    </div>

</body>
</html>

