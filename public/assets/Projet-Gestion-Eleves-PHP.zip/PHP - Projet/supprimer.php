<?php

    include_once "connexion.php";
    $id = $_GET['id'];
    $req = mysqli_query($conn, "DELETE FROM eleve WHERE id_eleve = $id");
    header("location: eleves.php");
?>
