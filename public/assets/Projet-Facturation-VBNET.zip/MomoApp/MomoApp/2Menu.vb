﻿Public Class PMenu

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: cette ligne de code charge les données dans la table 'FournDataSet.Commande'. Vous pouvez la déplacer ou la supprimer selon vos besoins.
        Me.CommandeTableAdapter.Fill(Me.FournDataSet.Commande)
        'TODO: cette ligne de code charge les données dans la table 'FournDataSet.Client'. Vous pouvez la déplacer ou la supprimer selon vos besoins.
        Me.ClientTableAdapter.Fill(Me.FournDataSet.Client)
        'TODO: cette ligne de code charge les données dans la table 'FournDataSet.Produit'. Vous pouvez la déplacer ou la supprimer selon vos besoins.
        Me.ProduitTableAdapter.Fill(Me.FournDataSet.Produit)
        'TODO: cette ligne de code charge les données dans la table 'FournDataSet.Fournisseur'. Vous pouvez la déplacer ou la supprimer selon vos besoins.
        Me.FournisseurTableAdapter.Fill(Me.FournDataSet.Fournisseur)

    End Sub

    Private Sub TsFournisseur_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TsFournisseur.Click
        PFournisseur.Show()
    End Sub

    Private Sub TsClient_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TsClient.Click
        PClient.Show()
    End Sub

    Private Sub TsCommande_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TsCommande.Click
        PCommande.Show()
    End Sub

    Private Sub TsProduit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TsProduit.Click
        Produit.Show()
    End Sub

    Private Sub TsFacturation_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TsFacturation.Click
        Facturation.Show()
    End Sub

    Private Sub MenuStrip1_ItemClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles MenuStrip1.ItemClicked

    End Sub
End Class