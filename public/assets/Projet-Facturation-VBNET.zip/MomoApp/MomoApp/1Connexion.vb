﻿'Importation de References'
Imports System
Imports System.Data
Imports System.Data.OleDb

Public Class PConnexion

    Public cnn As OleDbConnection 'connexion a la Base de données'
    Public cmd As OleDbCommand 'Pour les requetes SQL'
    Public dtr As OleDbDataReader 'Lecteur de données'

    Private Sub BtnValider_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnValider.Click
        'Declaration variable de connexion'
        Dim cnn As New OleDbConnection("Provider = Microsoft.Jet.OleDb.4.0; Data Source = " & Application.StartupPath & "\Fournisseur.mdb")
        'Declaration variable de commande'
        Dim cmd As New OleDbCommand("SELECT * FROM Connexion WHERE Login = '" & TxtLogin.Text & "' AND Mdp = '" & TxtMdp.Text & "'", cnn)
        'Ouverture de la variable de connexion'
        cnn.Open()
        'Declaration variable de lecture'
        Dim dtr As OleDbDataReader = cmd.ExecuteReader

        'Verification du remplissage des champs'
        If TxtLogin.Text = "" Or TxtMdp.Text = "" Then
            MsgBox("Veuillez remplir les champs !", vbCritical, "ATTENTION")
            TxtLogin.Focus()
            Exit Sub
        End If

        'Verification que la requete c bien passée cad user et mdp correct'
        If dtr.Read() Then
            MessageBox.Show("Login et Mdp corrects Bienvenu !")
            PMenu.Show()
        Else
            MessageBox.Show("Login ou Mdp incorrects !")
            TxtLogin.Clear()
            TxtLogin.Focus()
        End If
    End Sub

    Private Sub BtnAnnuler_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnAnnuler.Click
        MessageBox.Show("Au Revoir !")
    End Sub

    Private Sub Form4_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class