﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Facturation
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.LblCommande = New System.Windows.Forms.Label()
        Me.TxtNumCommande = New System.Windows.Forms.TextBox()
        Me.BtnChercher = New System.Windows.Forms.Button()
        Me.TxtDate = New System.Windows.Forms.TextBox()
        Me.LblDate = New System.Windows.Forms.Label()
        Me.TxtClient = New System.Windows.Forms.TextBox()
        Me.LblClient = New System.Windows.Forms.Label()
        Me.DgvLignes = New System.Windows.Forms.DataGridView()
        Me.GrpTotaux = New System.Windows.Forms.GroupBox()
        Me.TxtTotalTTC = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TxtMontantTVA = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TxtMontantRemise = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.CbxRemise = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TxtTotalHT = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.BtnNouveau = New System.Windows.Forms.Button()
        Me.BtnApercu = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.TsFournisseur = New System.Windows.Forms.ToolStripMenuItem()
        Me.TsClient = New System.Windows.Forms.ToolStripMenuItem()
        Me.TsCommande = New System.Windows.Forms.ToolStripMenuItem()
        Me.TsProduit = New System.Windows.Forms.ToolStripMenuItem()
        Me.TsFacturation = New System.Windows.Forms.ToolStripMenuItem()
        Me.Panel2 = New System.Windows.Forms.Panel()
        CType(Me.DgvLignes, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GrpTotaux.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'LblCommande
        '
        Me.LblCommande.AutoSize = True
        Me.LblCommande.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblCommande.Location = New System.Drawing.Point(240, 124)
        Me.LblCommande.Name = "LblCommande"
        Me.LblCommande.Size = New System.Drawing.Size(215, 28)
        Me.LblCommande.TabIndex = 0
        Me.LblCommande.Text = "Num Commande"
        '
        'TxtNumCommande
        '
        Me.TxtNumCommande.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtNumCommande.Location = New System.Drawing.Point(480, 124)
        Me.TxtNumCommande.Name = "TxtNumCommande"
        Me.TxtNumCommande.Size = New System.Drawing.Size(255, 37)
        Me.TxtNumCommande.TabIndex = 1
        '
        'BtnChercher
        '
        Me.BtnChercher.BackColor = System.Drawing.SystemColors.Highlight
        Me.BtnChercher.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnChercher.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.BtnChercher.Location = New System.Drawing.Point(779, 112)
        Me.BtnChercher.Name = "BtnChercher"
        Me.BtnChercher.Size = New System.Drawing.Size(180, 52)
        Me.BtnChercher.TabIndex = 2
        Me.BtnChercher.Text = "Rechercher"
        Me.BtnChercher.UseVisualStyleBackColor = False
        '
        'TxtDate
        '
        Me.TxtDate.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.TxtDate.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtDate.Location = New System.Drawing.Point(480, 234)
        Me.TxtDate.Name = "TxtDate"
        Me.TxtDate.ReadOnly = True
        Me.TxtDate.Size = New System.Drawing.Size(255, 37)
        Me.TxtDate.TabIndex = 4
        '
        'LblDate
        '
        Me.LblDate.AutoSize = True
        Me.LblDate.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblDate.Location = New System.Drawing.Point(388, 230)
        Me.LblDate.Name = "LblDate"
        Me.LblDate.Size = New System.Drawing.Size(67, 28)
        Me.LblDate.TabIndex = 3
        Me.LblDate.Text = "Date"
        '
        'TxtClient
        '
        Me.TxtClient.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.TxtClient.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtClient.Location = New System.Drawing.Point(480, 177)
        Me.TxtClient.Name = "TxtClient"
        Me.TxtClient.ReadOnly = True
        Me.TxtClient.Size = New System.Drawing.Size(255, 37)
        Me.TxtClient.TabIndex = 7
        '
        'LblClient
        '
        Me.LblClient.AutoSize = True
        Me.LblClient.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblClient.Location = New System.Drawing.Point(376, 177)
        Me.LblClient.Name = "LblClient"
        Me.LblClient.Size = New System.Drawing.Size(79, 28)
        Me.LblClient.TabIndex = 6
        Me.LblClient.Text = "Client"
        '
        'DgvLignes
        '
        Me.DgvLignes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgvLignes.Location = New System.Drawing.Point(36, 287)
        Me.DgvLignes.Name = "DgvLignes"
        Me.DgvLignes.RowTemplate.Height = 28
        Me.DgvLignes.Size = New System.Drawing.Size(923, 152)
        Me.DgvLignes.TabIndex = 8
        '
        'GrpTotaux
        '
        Me.GrpTotaux.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.GrpTotaux.Controls.Add(Me.TxtTotalTTC)
        Me.GrpTotaux.Controls.Add(Me.Label5)
        Me.GrpTotaux.Controls.Add(Me.TxtMontantTVA)
        Me.GrpTotaux.Controls.Add(Me.Label4)
        Me.GrpTotaux.Controls.Add(Me.TxtMontantRemise)
        Me.GrpTotaux.Controls.Add(Me.Label3)
        Me.GrpTotaux.Controls.Add(Me.CbxRemise)
        Me.GrpTotaux.Controls.Add(Me.Label2)
        Me.GrpTotaux.Controls.Add(Me.TxtTotalHT)
        Me.GrpTotaux.Controls.Add(Me.Label1)
        Me.GrpTotaux.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GrpTotaux.Location = New System.Drawing.Point(36, 500)
        Me.GrpTotaux.Name = "GrpTotaux"
        Me.GrpTotaux.Size = New System.Drawing.Size(923, 237)
        Me.GrpTotaux.TabIndex = 9
        Me.GrpTotaux.TabStop = False
        Me.GrpTotaux.Text = "Totaux"
        '
        'TxtTotalTTC
        '
        Me.TxtTotalTTC.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.TxtTotalTTC.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtTotalTTC.Location = New System.Drawing.Point(154, 166)
        Me.TxtTotalTTC.Name = "TxtTotalTTC"
        Me.TxtTotalTTC.ReadOnly = True
        Me.TxtTotalTTC.Size = New System.Drawing.Size(187, 37)
        Me.TxtTotalTTC.TabIndex = 17
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(23, 175)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(112, 28)
        Me.Label5.TabIndex = 16
        Me.Label5.Text = "Total TTC"
        '
        'TxtMontantTVA
        '
        Me.TxtMontantTVA.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.TxtMontantTVA.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtMontantTVA.Location = New System.Drawing.Point(154, 103)
        Me.TxtMontantTVA.Name = "TxtMontantTVA"
        Me.TxtMontantTVA.ReadOnly = True
        Me.TxtMontantTVA.Size = New System.Drawing.Size(187, 37)
        Me.TxtMontantTVA.TabIndex = 15
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(23, 112)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(57, 28)
        Me.Label4.TabIndex = 14
        Me.Label4.Text = "TVA"
        '
        'TxtMontantRemise
        '
        Me.TxtMontantRemise.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.TxtMontantRemise.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtMontantRemise.Location = New System.Drawing.Point(653, 100)
        Me.TxtMontantRemise.Name = "TxtMontantRemise"
        Me.TxtMontantRemise.ReadOnly = True
        Me.TxtMontantRemise.Size = New System.Drawing.Size(195, 37)
        Me.TxtMontantRemise.TabIndex = 13
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(439, 103)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(198, 28)
        Me.Label3.TabIndex = 12
        Me.Label3.Text = "Montant Remise"
        '
        'CbxRemise
        '
        Me.CbxRemise.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CbxRemise.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CbxRemise.FormattingEnabled = True
        Me.CbxRemise.Items.AddRange(New Object() {"0%", "5%", "10%", "15%", "20%"})
        Me.CbxRemise.Location = New System.Drawing.Point(712, 45)
        Me.CbxRemise.Name = "CbxRemise"
        Me.CbxRemise.Size = New System.Drawing.Size(136, 38)
        Me.CbxRemise.TabIndex = 11
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(537, 53)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(135, 28)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "Remise(%)"
        '
        'TxtTotalHT
        '
        Me.TxtTotalHT.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.TxtTotalHT.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtTotalHT.Location = New System.Drawing.Point(154, 44)
        Me.TxtTotalHT.Name = "TxtTotalHT"
        Me.TxtTotalHT.ReadOnly = True
        Me.TxtTotalHT.Size = New System.Drawing.Size(187, 37)
        Me.TxtTotalHT.TabIndex = 9
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(23, 53)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(99, 28)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "Total HT"
        '
        'BtnNouveau
        '
        Me.BtnNouveau.BackColor = System.Drawing.SystemColors.Highlight
        Me.BtnNouveau.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnNouveau.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.BtnNouveau.Location = New System.Drawing.Point(128, 770)
        Me.BtnNouveau.Name = "BtnNouveau"
        Me.BtnNouveau.Size = New System.Drawing.Size(346, 76)
        Me.BtnNouveau.TabIndex = 10
        Me.BtnNouveau.Text = "Nouvelle Facture"
        Me.BtnNouveau.UseVisualStyleBackColor = False
        '
        'BtnApercu
        '
        Me.BtnApercu.BackColor = System.Drawing.SystemColors.Highlight
        Me.BtnApercu.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnApercu.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.BtnApercu.Location = New System.Drawing.Point(480, 770)
        Me.BtnApercu.Name = "BtnApercu"
        Me.BtnApercu.Size = New System.Drawing.Size(353, 76)
        Me.BtnApercu.TabIndex = 11
        Me.BtnApercu.Text = "Apercu Facture"
        Me.BtnApercu.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.SystemColors.Highlight
        Me.Button1.Font = New System.Drawing.Font("Century Gothic", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.Button1.Location = New System.Drawing.Point(238, 14)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(497, 76)
        Me.Button1.TabIndex = 12
        Me.Button1.Text = "FACTURATION"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.SystemColors.Highlight
        Me.MenuStrip1.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TsFournisseur, Me.TsClient, Me.TsCommande, Me.TsProduit, Me.TsFacturation})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(992, 31)
        Me.MenuStrip1.TabIndex = 59
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'TsFournisseur
        '
        Me.TsFournisseur.ForeColor = System.Drawing.SystemColors.Window
        Me.TsFournisseur.Name = "TsFournisseur"
        Me.TsFournisseur.Size = New System.Drawing.Size(129, 27)
        Me.TsFournisseur.Text = "Fournisseur"
        '
        'TsClient
        '
        Me.TsClient.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TsClient.ForeColor = System.Drawing.SystemColors.Window
        Me.TsClient.Name = "TsClient"
        Me.TsClient.Size = New System.Drawing.Size(79, 27)
        Me.TsClient.Text = "Client"
        '
        'TsCommande
        '
        Me.TsCommande.ForeColor = System.Drawing.SystemColors.Window
        Me.TsCommande.Name = "TsCommande"
        Me.TsCommande.Size = New System.Drawing.Size(140, 27)
        Me.TsCommande.Text = "Commande"
        '
        'TsProduit
        '
        Me.TsProduit.ForeColor = System.Drawing.SystemColors.Window
        Me.TsProduit.Name = "TsProduit"
        Me.TsProduit.Size = New System.Drawing.Size(88, 27)
        Me.TsProduit.Text = "Produit"
        '
        'TsFacturation
        '
        Me.TsFacturation.ForeColor = System.Drawing.SystemColors.Window
        Me.TsFacturation.Name = "TsFacturation"
        Me.TsFacturation.Size = New System.Drawing.Size(131, 27)
        Me.TsFacturation.Text = "Facturation"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Panel2.Controls.Add(Me.Button1)
        Me.Panel2.Controls.Add(Me.LblCommande)
        Me.Panel2.Controls.Add(Me.TxtNumCommande)
        Me.Panel2.Controls.Add(Me.BtnApercu)
        Me.Panel2.Controls.Add(Me.BtnChercher)
        Me.Panel2.Controls.Add(Me.BtnNouveau)
        Me.Panel2.Controls.Add(Me.LblDate)
        Me.Panel2.Controls.Add(Me.GrpTotaux)
        Me.Panel2.Controls.Add(Me.TxtDate)
        Me.Panel2.Controls.Add(Me.DgvLignes)
        Me.Panel2.Controls.Add(Me.LblClient)
        Me.Panel2.Controls.Add(Me.TxtClient)
        Me.Panel2.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel2.Location = New System.Drawing.Point(0, 34)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(992, 883)
        Me.Panel2.TabIndex = 61
        '
        'Facturation
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(992, 913)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Name = "Facturation"
        Me.Text = "Form1"
        CType(Me.DgvLignes, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GrpTotaux.ResumeLayout(False)
        Me.GrpTotaux.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents LblCommande As System.Windows.Forms.Label
    Friend WithEvents TxtNumCommande As System.Windows.Forms.TextBox
    Friend WithEvents BtnChercher As System.Windows.Forms.Button
    Friend WithEvents TxtDate As System.Windows.Forms.TextBox
    Friend WithEvents LblDate As System.Windows.Forms.Label
    Friend WithEvents TxtClient As System.Windows.Forms.TextBox
    Friend WithEvents LblClient As System.Windows.Forms.Label
    Friend WithEvents DgvLignes As System.Windows.Forms.DataGridView
    Friend WithEvents GrpTotaux As System.Windows.Forms.GroupBox
    Friend WithEvents TxtTotalTTC As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents TxtMontantTVA As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents TxtMontantRemise As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents CbxRemise As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TxtTotalHT As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents BtnNouveau As System.Windows.Forms.Button
    Friend WithEvents BtnApercu As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents TsFournisseur As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TsClient As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TsCommande As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TsProduit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TsFacturation As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
End Class
