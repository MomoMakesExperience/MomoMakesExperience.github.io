﻿Imports System.Data.OleDb
Public Class Facturation

    Private Sub TsFournisseur_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TsFournisseur.Click
        PFournisseur.Show()
    End Sub

    Private Sub TsClient_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TsClient.Click
        PClient.Show()
    End Sub

    Private Sub TsCommande_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TsCommande.Click
        PCommande.Show()
    End Sub

    Private Sub TsProduit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TsProduit.Click
        Produit.Show()
    End Sub

    Private Sub TsFacturation_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TsFacturation.Click
        Me.Show()
    End Sub

    ' Variables pour garder les totaux en mémoire (avant remise)
    Private totalHT As Double
    Private totalTVA As Double

    'Fonction Rechercher '
    Private Sub BtnChercher_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnChercher.Click

        Dim cnn As New OleDbConnection("Provider = Microsoft.Jet.OleDb.4.0; Data Source = " & Application.StartupPath & "\Fournisseur.mdb")
        cnn.Open()

        ' 1. Recuperer la date de la commande et le client'
        Dim cmd As New OleDbCommand("SELECT C.DateCommande, Cl.Nom, Cl.Prénom FROM Commande C INNER JOIN Client Cl ON C.IdClient = Cl.IdClient WHERE C.NumCommande = '" & TxtNumCommande.Text & "'", cnn)
        Dim dtr As OleDbDataReader = cmd.ExecuteReader

        If dtr.Read() Then
            TxtDate.Text = dtr(0).ToString
            TxtClient.Text = dtr(1).ToString & " " & dtr(2).ToString
        Else
            MessageBox.Show("Il existe aucune commande sur ce numero")
            dtr.Close()
            cnn.Close()
            Exit Sub
        End If
        dtr.Close()

        ' 2. Recuperer les lignes de la commande (articles + quantites)'
        Dim cmd2 As New OleDbCommand("SELECT P.Designation, P.PrixUnitaire, L.Quantite, P.TVA FROM LigneCommande L INNER JOIN Produit P ON L.CodeProduit = P.CodeProduit WHERE L.NumCommande = '" & TxtNumCommande.Text & "'", cnn)
        Dim dtr2 As OleDbDataReader = cmd2.ExecuteReader

        Dim dt As New DataTable
        dt.Columns.Add("Designation")
        dt.Columns.Add("PrixUnitaire")
        dt.Columns.Add("Quantite")
        dt.Columns.Add("Montant")

        totalHT = 0
        totalTVA = 0

        While dtr2.Read()
            Dim prix As Double = dtr2(1)
            Dim qte As Integer = dtr2(2)
            Dim tva As Double = dtr2(3)
            Dim montant As Double = prix * qte

            totalHT = totalHT + montant
            totalTVA = totalTVA + (montant * tva / 100)

            dt.Rows.Add(dtr2(0), prix, qte, montant)
        End While
        dtr2.Close()

        DgvLignes.DataSource = dt

        Call CalculerTotaux()

        'Fermeture de la connexion'
        cnn.Close()

    End Sub

    ' ---------- Recalcule quand on choisit une remise ----------
    Private Sub CbxRemise_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CbxRemise.SelectedIndexChanged
        Call CalculerTotaux()
    End Sub

    ' ---------- Procedure de calcul (comme une sous-procedure classique) ----------
    Private Sub CalculerTotaux()

        Dim tauxRemise As Double
        tauxRemise = 0
        If CbxRemise.Text <> "" Then
            tauxRemise = Val(CbxRemise.Text.Replace("%", "")) / 100
        End If

        Dim montantRemise As Double
        montantRemise = totalHT * tauxRemise

        Dim totalTTC As Double
        totalTTC = (totalHT - montantRemise) + totalTVA

        TxtTotalHT.Text = totalHT
        TxtMontantRemise.Text = montantRemise
        TxtMontantTVA.Text = totalTVA
        TxtTotalTTC.Text = totalTTC

    End Sub

    ' ---------- Nouvelle facture (Effacer) ----------
    Private Sub BtnNouveau_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnNouveau.Click
        TxtNumCommande.Clear()
        TxtClient.Clear()
        TxtDate.Clear()
        TxtTotalHT.Clear()
        TxtMontantRemise.Clear()
        TxtMontantTVA.Clear()
        TxtTotalTTC.Clear()
        CbxRemise.Text = ""
        DgvLignes.DataSource = Nothing
        totalHT = 0
        totalTVA = 0
        TxtNumCommande.Focus()
    End Sub

    ' ---------- Apercu de la facture ----------
    Private Sub BtnApercu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnApercu.Click

        If TxtNumCommande.Text = "" Then
            MessageBox.Show("Recherche d'abord une commande")
            Exit Sub
        End If

        Dim apercu As String
        apercu = "FACTURE N° " & TxtNumCommande.Text & " " & vbCrLf
        apercu = apercu & "Client : " & TxtClient.Text & vbCrLf
        apercu = apercu & "Date : " & TxtDate.Text & vbCrLf & vbCrLf
        apercu = apercu & "Total HT : " & TxtTotalHT.Text & vbCrLf
        apercu = apercu & "Remise : " & TxtMontantRemise.Text & vbCrLf
        apercu = apercu & "TVA : " & TxtMontantTVA.Text & vbCrLf
        apercu = apercu & "TOTAL TTC : " & TxtTotalTTC.Text

        MessageBox.Show(apercu, "Apercu Facture")

    End Sub


End Class

