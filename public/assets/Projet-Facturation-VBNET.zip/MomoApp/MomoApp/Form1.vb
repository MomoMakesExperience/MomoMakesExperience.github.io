﻿Public Class Form1

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: cette ligne de code charge les données dans la table 'FournDataSet.Commande'. Vous pouvez la déplacer ou la supprimer selon vos besoins.
        Me.CommandeTableAdapter.Fill(Me.FournDataSet.Commande)

    End Sub
End Class