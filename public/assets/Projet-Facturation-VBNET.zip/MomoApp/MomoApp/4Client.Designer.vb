﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PClient
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.BtnModifier = New System.Windows.Forms.Button()
        Me.BtnAjouter = New System.Windows.Forms.Button()
        Me.BtnSupprimer = New System.Windows.Forms.Button()
        Me.BtnEffacer = New System.Windows.Forms.Button()
        Me.BtnRecherche = New System.Windows.Forms.Button()
        Me.BtnSuivant = New System.Windows.Forms.Button()
        Me.BtnPrecedent = New System.Windows.Forms.Button()
        Me.ClientBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.FournDataSet = New WindowsApplication1.FournDataSet()
        Me.ClientTableAdapter = New WindowsApplication1.FournDataSetTableAdapters.ClientTableAdapter()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.TsFournisseur = New System.Windows.Forms.ToolStripMenuItem()
        Me.TsClient = New System.Windows.Forms.ToolStripMenuItem()
        Me.TsCommande = New System.Windows.Forms.ToolStripMenuItem()
        Me.TsProduit = New System.Windows.Forms.ToolStripMenuItem()
        Me.TsFacturation = New System.Windows.Forms.ToolStripMenuItem()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TxtID = New System.Windows.Forms.TextBox()
        Me.TxtTel = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TxtAdd = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TxtCP = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TxtEmail = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TxtPrenom = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TxtNom = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        CType(Me.ClientBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FournDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'BtnModifier
        '
        Me.BtnModifier.BackColor = System.Drawing.SystemColors.HotTrack
        Me.BtnModifier.Font = New System.Drawing.Font("Century Gothic", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnModifier.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.BtnModifier.Location = New System.Drawing.Point(18, 278)
        Me.BtnModifier.Name = "BtnModifier"
        Me.BtnModifier.Size = New System.Drawing.Size(198, 80)
        Me.BtnModifier.TabIndex = 51
        Me.BtnModifier.Text = "Modifier"
        Me.BtnModifier.UseVisualStyleBackColor = False
        '
        'BtnAjouter
        '
        Me.BtnAjouter.BackColor = System.Drawing.SystemColors.HotTrack
        Me.BtnAjouter.Font = New System.Drawing.Font("Century Gothic", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnAjouter.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.BtnAjouter.Location = New System.Drawing.Point(18, 101)
        Me.BtnAjouter.Name = "BtnAjouter"
        Me.BtnAjouter.Size = New System.Drawing.Size(196, 79)
        Me.BtnAjouter.TabIndex = 50
        Me.BtnAjouter.Text = "Ajouter"
        Me.BtnAjouter.UseVisualStyleBackColor = False
        '
        'BtnSupprimer
        '
        Me.BtnSupprimer.BackColor = System.Drawing.SystemColors.HotTrack
        Me.BtnSupprimer.Font = New System.Drawing.Font("Century Gothic", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSupprimer.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.BtnSupprimer.Location = New System.Drawing.Point(18, 364)
        Me.BtnSupprimer.Name = "BtnSupprimer"
        Me.BtnSupprimer.Size = New System.Drawing.Size(198, 78)
        Me.BtnSupprimer.TabIndex = 48
        Me.BtnSupprimer.Text = "Supprimer"
        Me.BtnSupprimer.UseVisualStyleBackColor = False
        '
        'BtnEffacer
        '
        Me.BtnEffacer.BackColor = System.Drawing.SystemColors.HotTrack
        Me.BtnEffacer.Font = New System.Drawing.Font("Century Gothic", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnEffacer.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.BtnEffacer.Location = New System.Drawing.Point(20, 191)
        Me.BtnEffacer.Name = "BtnEffacer"
        Me.BtnEffacer.Size = New System.Drawing.Size(196, 81)
        Me.BtnEffacer.TabIndex = 47
        Me.BtnEffacer.Text = "Effacer"
        Me.BtnEffacer.UseVisualStyleBackColor = False
        '
        'BtnRecherche
        '
        Me.BtnRecherche.BackColor = System.Drawing.SystemColors.HotTrack
        Me.BtnRecherche.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnRecherche.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.BtnRecherche.Location = New System.Drawing.Point(18, 452)
        Me.BtnRecherche.Name = "BtnRecherche"
        Me.BtnRecherche.Size = New System.Drawing.Size(196, 78)
        Me.BtnRecherche.TabIndex = 46
        Me.BtnRecherche.Text = "Rechercher"
        Me.BtnRecherche.UseVisualStyleBackColor = False
        '
        'BtnSuivant
        '
        Me.BtnSuivant.BackColor = System.Drawing.SystemColors.HotTrack
        Me.BtnSuivant.Font = New System.Drawing.Font("Century Gothic", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSuivant.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.BtnSuivant.Location = New System.Drawing.Point(116, 538)
        Me.BtnSuivant.Name = "BtnSuivant"
        Me.BtnSuivant.Size = New System.Drawing.Size(98, 91)
        Me.BtnSuivant.TabIndex = 44
        Me.BtnSuivant.Text = "►"
        Me.BtnSuivant.UseVisualStyleBackColor = False
        '
        'BtnPrecedent
        '
        Me.BtnPrecedent.BackColor = System.Drawing.SystemColors.HotTrack
        Me.BtnPrecedent.Font = New System.Drawing.Font("Century Gothic", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnPrecedent.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.BtnPrecedent.Location = New System.Drawing.Point(18, 538)
        Me.BtnPrecedent.Name = "BtnPrecedent"
        Me.BtnPrecedent.Size = New System.Drawing.Size(96, 91)
        Me.BtnPrecedent.TabIndex = 43
        Me.BtnPrecedent.Text = "◄"
        Me.BtnPrecedent.UseVisualStyleBackColor = False
        '
        'ClientBindingSource
        '
        Me.ClientBindingSource.DataMember = "Client"
        Me.ClientBindingSource.DataSource = Me.FournDataSet
        '
        'FournDataSet
        '
        Me.FournDataSet.DataSetName = "FournDataSet"
        Me.FournDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ClientTableAdapter
        '
        Me.ClientTableAdapter.ClearBeforeFill = True
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.SystemColors.HighlightText
        Me.Panel3.Controls.Add(Me.Label8)
        Me.Panel3.Controls.Add(Me.BtnEffacer)
        Me.Panel3.Controls.Add(Me.BtnModifier)
        Me.Panel3.Controls.Add(Me.BtnAjouter)
        Me.Panel3.Controls.Add(Me.BtnSupprimer)
        Me.Panel3.Controls.Add(Me.BtnSuivant)
        Me.Panel3.Controls.Add(Me.BtnRecherche)
        Me.Panel3.Controls.Add(Me.BtnPrecedent)
        Me.Panel3.Location = New System.Drawing.Point(739, 34)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(238, 684)
        Me.Panel3.TabIndex = 55
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Century Gothic", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label8.Location = New System.Drawing.Point(46, 46)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(138, 38)
        Me.Label8.TabIndex = 52
        Me.Label8.Text = "Boutons"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.SystemColors.Highlight
        Me.MenuStrip1.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TsFournisseur, Me.TsClient, Me.TsCommande, Me.TsProduit, Me.TsFacturation})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(977, 31)
        Me.MenuStrip1.TabIndex = 53
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'TsFournisseur
        '
        Me.TsFournisseur.ForeColor = System.Drawing.SystemColors.Window
        Me.TsFournisseur.Name = "TsFournisseur"
        Me.TsFournisseur.Size = New System.Drawing.Size(129, 27)
        Me.TsFournisseur.Text = "Fournisseur"
        '
        'TsClient
        '
        Me.TsClient.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TsClient.ForeColor = System.Drawing.SystemColors.Window
        Me.TsClient.Name = "TsClient"
        Me.TsClient.Size = New System.Drawing.Size(79, 27)
        Me.TsClient.Text = "Client"
        '
        'TsCommande
        '
        Me.TsCommande.ForeColor = System.Drawing.SystemColors.Window
        Me.TsCommande.Name = "TsCommande"
        Me.TsCommande.Size = New System.Drawing.Size(140, 27)
        Me.TsCommande.Text = "Commande"
        '
        'TsProduit
        '
        Me.TsProduit.ForeColor = System.Drawing.SystemColors.Window
        Me.TsProduit.Name = "TsProduit"
        Me.TsProduit.Size = New System.Drawing.Size(88, 27)
        Me.TsProduit.Text = "Produit"
        '
        'TsFacturation
        '
        Me.TsFacturation.ForeColor = System.Drawing.SystemColors.Window
        Me.TsFacturation.Name = "TsFacturation"
        Me.TsFacturation.Size = New System.Drawing.Size(131, 27)
        Me.TsFacturation.Text = "Facturation"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Panel2.Controls.Add(Me.Button1)
        Me.Panel2.Controls.Add(Me.TxtID)
        Me.Panel2.Controls.Add(Me.TxtTel)
        Me.Panel2.Controls.Add(Me.Label5)
        Me.Panel2.Controls.Add(Me.TxtAdd)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Controls.Add(Me.TxtCP)
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Controls.Add(Me.TxtEmail)
        Me.Panel2.Controls.Add(Me.Label7)
        Me.Panel2.Controls.Add(Me.TxtPrenom)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Controls.Add(Me.TxtNom)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Location = New System.Drawing.Point(0, 34)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(733, 684)
        Me.Panel2.TabIndex = 54
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.SystemColors.Highlight
        Me.Button1.Font = New System.Drawing.Font("Century Gothic", 28.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.Button1.Location = New System.Drawing.Point(200, 25)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(475, 79)
        Me.Button1.TabIndex = 54
        Me.Button1.Text = "CLIENTS"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'TxtID
        '
        Me.TxtID.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ClientBindingSource, "IdClient", True))
        Me.TxtID.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtID.Location = New System.Drawing.Point(200, 138)
        Me.TxtID.Name = "TxtID"
        Me.TxtID.Size = New System.Drawing.Size(475, 42)
        Me.TxtID.TabIndex = 26
        '
        'TxtTel
        '
        Me.TxtTel.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ClientBindingSource, "Tel", True))
        Me.TxtTel.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtTel.Location = New System.Drawing.Point(200, 433)
        Me.TxtTel.Name = "TxtTel"
        Me.TxtTel.Size = New System.Drawing.Size(475, 42)
        Me.TxtTel.TabIndex = 30
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.Desktop
        Me.Label5.Location = New System.Drawing.Point(29, 433)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(158, 34)
        Me.Label5.TabIndex = 38
        Me.Label5.Text = "Téléphone"
        '
        'TxtAdd
        '
        Me.TxtAdd.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ClientBindingSource, "Adresse", True))
        Me.TxtAdd.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtAdd.Location = New System.Drawing.Point(200, 356)
        Me.TxtAdd.Name = "TxtAdd"
        Me.TxtAdd.Size = New System.Drawing.Size(475, 42)
        Me.TxtAdd.TabIndex = 29
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.Desktop
        Me.Label6.Location = New System.Drawing.Point(17, 516)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(170, 34)
        Me.Label6.TabIndex = 39
        Me.Label6.Text = "CodePostal"
        '
        'TxtCP
        '
        Me.TxtCP.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ClientBindingSource, "CodePostal", True))
        Me.TxtCP.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtCP.Location = New System.Drawing.Point(200, 513)
        Me.TxtCP.Name = "TxtCP"
        Me.TxtCP.Size = New System.Drawing.Size(475, 42)
        Me.TxtCP.TabIndex = 31
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.Desktop
        Me.Label4.Location = New System.Drawing.Point(54, 356)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(123, 34)
        Me.Label4.TabIndex = 37
        Me.Label4.Text = "Adresse"
        '
        'TxtEmail
        '
        Me.TxtEmail.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ClientBindingSource, "Email", True))
        Me.TxtEmail.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtEmail.Location = New System.Drawing.Point(200, 589)
        Me.TxtEmail.Name = "TxtEmail"
        Me.TxtEmail.Size = New System.Drawing.Size(475, 42)
        Me.TxtEmail.TabIndex = 32
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.Desktop
        Me.Label7.Location = New System.Drawing.Point(83, 589)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(88, 34)
        Me.Label7.TabIndex = 40
        Me.Label7.Text = "Email"
        '
        'TxtPrenom
        '
        Me.TxtPrenom.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ClientBindingSource, "Prénom", True))
        Me.TxtPrenom.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtPrenom.Location = New System.Drawing.Point(200, 283)
        Me.TxtPrenom.Name = "TxtPrenom"
        Me.TxtPrenom.Size = New System.Drawing.Size(475, 42)
        Me.TxtPrenom.TabIndex = 28
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.Desktop
        Me.Label3.Location = New System.Drawing.Point(59, 283)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(119, 34)
        Me.Label3.TabIndex = 36
        Me.Label3.Text = "Prénom"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.Desktop
        Me.Label1.Location = New System.Drawing.Point(58, 138)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(120, 34)
        Me.Label1.TabIndex = 34
        Me.Label1.Text = "IdClient"
        '
        'TxtNom
        '
        Me.TxtNom.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ClientBindingSource, "Nom", True))
        Me.TxtNom.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtNom.Location = New System.Drawing.Point(200, 205)
        Me.TxtNom.Name = "TxtNom"
        Me.TxtNom.Size = New System.Drawing.Size(475, 42)
        Me.TxtNom.TabIndex = 27
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.Desktop
        Me.Label2.Location = New System.Drawing.Point(89, 205)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(80, 34)
        Me.Label2.TabIndex = 35
        Me.Label2.Text = "Nom"
        '
        'PClient
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(977, 720)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Name = "PClient"
        Me.Text = "Form5"
        CType(Me.ClientBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FournDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents BtnModifier As System.Windows.Forms.Button
    Friend WithEvents BtnAjouter As System.Windows.Forms.Button
    Friend WithEvents BtnSupprimer As System.Windows.Forms.Button
    Friend WithEvents BtnEffacer As System.Windows.Forms.Button
    Friend WithEvents BtnRecherche As System.Windows.Forms.Button
    Friend WithEvents BtnSuivant As System.Windows.Forms.Button
    Friend WithEvents BtnPrecedent As System.Windows.Forms.Button
    Friend WithEvents FournDataSet As WindowsApplication1.FournDataSet
    Friend WithEvents ClientBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents ClientTableAdapter As WindowsApplication1.FournDataSetTableAdapters.ClientTableAdapter
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents TsFournisseur As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TsClient As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TsCommande As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TsProduit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TsFacturation As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents TxtID As System.Windows.Forms.TextBox
    Friend WithEvents TxtTel As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents TxtAdd As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents TxtCP As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents TxtEmail As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents TxtPrenom As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TxtNom As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
End Class
