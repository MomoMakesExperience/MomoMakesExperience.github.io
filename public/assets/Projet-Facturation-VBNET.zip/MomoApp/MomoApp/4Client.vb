﻿'Inclusion de Références'
Imports System
Imports System.Data
Imports System.Data.OleDb
Imports Microsoft.Office.Interop

Public Class PClient

    'Declaration de variables'
    Public cnn As OleDbConnection 'connexion a la Base de données'
    Public cmd As OleDbCommand 'Pour les requetes SQL'
    Public dtr As OleDbDataReader 'Lecteur de données'
    Private strSQL, strConn As String
    Public dta As OleDbDataAdapter 'Pour recupèrer les données modifier inserer entre la base et Dataset'
    Private cmb As OleDbCommandBuilder

    Private Sub TsFournisseur_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TsFournisseur.Click
        PFournisseur.Show()
    End Sub

    Private Sub TsClient_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TsClient.Click
        Me.Show()
    End Sub

    Private Sub TsCommande_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TsCommande.Click
        PCommande.Show()
    End Sub

    Private Sub TsProduit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TsProduit.Click
        Produit.Show()
    End Sub

    Private Sub TsFacturation_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TsFacturation.Click
        Facturation.Show()
    End Sub

    Private Sub Form5_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: cette ligne de code charge les données dans la table 'FournDataSet.Client'. Vous pouvez la déplacer ou la supprimer selon vos besoins.
        Me.ClientTableAdapter.Fill(Me.FournDataSet.Client)

    End Sub

    'Procédure pour voir le précédent'
    Private Sub BtnPrecedent_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnPrecedent.Click
        ClientBindingSource.MovePrevious()
    End Sub

    'Procédure pour voir le suivant'
    Private Sub BtnSuivant_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnSuivant.Click
        ClientBindingSource.MoveNext()
    End Sub

    'On veut faire une extraction de données'
    Private Sub BtnRecherche_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnRecherche.Click
        Dim cnn As New OleDbConnection("Provider = Microsoft.Jet.OleDb.4.0; Data Source = " & Application.StartupPath & "\Fournisseur.mdb")
        'Si on a une zone de texte on met les apostrophes sinon on ne met pas'
        Dim cmd As New OleDbCommand("SELECT * FROM Client WHERE IdClient = '" & TxtID.Text & "'", cnn)
        'Ouverture de la connection'
        cnn.Open()
        'Execution de la commande'
        Dim dtr As OleDbDataReader = cmd.ExecuteReader
        'Condition de Lecture'
        If dtr.Read() Then
            MessageBox.Show("Il existe un client sur ce ID")
            'On rempli les infos de la base dans le formulaire'
            TxtID.Text = dtr(0).ToString
            TxtNom.Text = dtr(1).ToString
            TxtPrenom.Text = dtr(2).ToString
            TxtAdd.Text = dtr(3).ToString
            TxtCP.Text = dtr(4).ToString
            TxtTel.Text = dtr(5).ToString
            TxtEmail.Text = dtr(6).ToString
        Else
            'Message d erreurs'
            MessageBox.Show("Il existe aucun client sur ce ID")
            TxtID.Clear()
            TxtID.Focus()
        End If
    End Sub

    Private Sub BtnEffacer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnEffacer.Click
        Me.TxtID.ResetText()
        Me.TxtNom.ResetText()
        Me.TxtPrenom.ResetText()
        Me.TxtAdd.ResetText()
        Me.TxtCP.ResetText()
        Me.TxtTel.ResetText()
        Me.TxtEmail.ResetText()
    End Sub

    'Procédure pour supprimer un fournisseur de la base de données
    Private Sub BtnSupprimer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnSupprimer.Click
        'Construction de la chaine de connexion vers la base de données Access
        strConn = "Provider = Microsoft.Jet.OleDb.4.0; Data Source = " & Application.StartupPath & "\Fournisseur.mdb"
        'Création de l'objet de connexion à la base de données
        cnn = New OleDbConnection()
        'Association de la chaine de connexion à l'objet connexion
        cnn.ConnectionString = strConn
        'Ouverture de la connexion à la base de données
        cnn.Open()
        'Création de l'objet commande qui permettra d'exécuter la requête SQL
        cmd = cnn.CreateCommand
        'Indication que la commande à exécuter est une requête SQL écrite en texte
        cmd.CommandType = CommandType.Text
        'Déclaration d'une variable pour récupérer la réponse de l'utilisateur
        Dim reponse As String
        'Création de la requête SQL permettant de supprimer le fournisseur correspondant à l'identifiant saisi
        strSQL = "DELETE FROM Client WHERE IdClient = '" & TxtID.Text & "'"
        'Affichage d'une boîte de dialogue demandant la confirmation de la suppression
        reponse = MsgBox("Voulez-vous vraiment supprimer ce client ?", vbYesNo, "Suppression")
        'Si l'utilisateur clique sur Oui
        If reponse = vbYes Then
            'Affichage d'un message indiquant que la suppression est effectuée
            MsgBox("Suppression effectuée !", , "Suppression")
            'Association de la requête SQL à l'objet commande
            cmd.CommandText = strSQL
            'Exécution de la requête SQL de suppression
            cmd.ExecuteNonQuery()
        Else
            'Affichage d'un message indiquant que la suppression a été annulée
            MsgBox("Suppression non effectuée !")
        End If
        'Effacement du contenu des zones de texte
        Me.TxtID.ResetText()
        Me.TxtNom.ResetText()
        Me.TxtPrenom.ResetText()
        Me.TxtAdd.ResetText()
        Me.TxtTel.ResetText()
        Me.TxtCP.ResetText()
        Me.TxtEmail.ResetText()

        cnn.Close()
    End Sub

    Private Sub BtnAjouter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnAjouter.Click
        'Connexion a la base je lui donne le nom de la base et la machine va la trouver'
        Dim cnn As New OleDbConnection("Provider = Microsoft.Jet.OleDb.4.0; Data Source = " & Application.StartupPath & "\Fournisseur.mdb")
        'Si on a une zone de texte on met les apostrophes sinon on ne met pas'
        Dim cmd As New OleDbCommand("SELECT * FROM Client WHERE IdClient = '" & TxtID.Text & "'", cnn)
        'Ouverture de la connection'
        cnn.Open()
        'Lecture des données'
        Dim dtr As OleDbDataReader = cmd.ExecuteReader
        'Préparation des données à recupèrer'
        Dim dta As New OleDbDataAdapter(cmd)
        'Stockage des données en mémoire'
        Dim dts As New DataSet
        If dtr.Read() Then
            MessageBox.Show("Ce client existe déjà !")
            'Effacement des zones de textes et Renvoie du curseur au niveau de la zone de texte du ID'
            TxtID.Clear()
            TxtID.Focus()
            TxtNom.Clear()
            TxtPrenom.Clear()
            TxtAdd.Clear()
            TxtTel.Clear()
            TxtCP.Clear()
            TxtEmail.Clear()
        Else
            dtr.Close()
            'C'est une methode qui nous permet de remplir notre DataSet oubien notre Table : Fournisseur'
            dta.Fill(dts, "Client")
            'Ajout d une nouvelle ligne dans ma table Fournisseur'
            dts.Tables("Client").Rows.Add(New Object() {TxtID.Text, TxtNom.Text, TxtPrenom.Text, TxtAdd.Text, TxtCP.Text, TxtTel.Text, TxtEmail.Text})
            'Nous permet de créer des requetes SQL (INSERT, UPDATE, DELETE...) et complete le dataAdapter la on a deja la requete donc il modifie juste la table'
            'Ne pas oublier que le DataAdapter dta a la valeur de cmd '
            Dim cmb As New OleDbCommandBuilder(dta)
            dta.Update(dts, "Client")
            MessageBox.Show("Client Ajouté !")
            TxtID.Clear()
            TxtID.Focus()
            TxtNom.Clear()
            TxtPrenom.Clear()
            TxtAdd.Clear()
            TxtTel.Clear()
            TxtCP.Clear()
            TxtEmail.Clear()

            'Fermeture de la connexion'
            cnn.Close()
        End If
    End Sub

    Private Sub BtnModifier_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnModifier.Click
        'Construction de la chaine de connexion vers la base de données Access
        strConn = "Provider = Microsoft.Jet.OleDb.4.0; Data Source = " & Application.StartupPath & "\Fournisseur.mdb"
        'Création de l'objet de connexion à la base de données
        cnn = New OleDbConnection()
        'Association de la chaine de connexion à l'objet connexion
        cnn.ConnectionString = strConn
        'Ouverture de la connexion à la base de données
        cnn.Open()
        'Création de l'objet commande qui permettra d'exécuter la requête SQL
        cmd = cnn.CreateCommand
        'Indication que la commande à exécuter est une requête SQL écrite en texte
        cmd.CommandType = CommandType.Text
        'Déclaration d'une variable pour récupérer la réponse de l'utilisateur
        Dim reponse As String
        'Création de la requête SQL permettant de supprimer le fournisseur correspondant à l'identifiant saisi
        strSQL = "UPDATE Client SET Nom = '" & TxtNom.Text & "', Prénom = '" & TxtPrenom.Text & "', Adresse = '" & TxtAdd.Text & "', CodePostal = '" & TxtCP.Text & "', Tel = '" & TxtTel.Text & "', Email = '" & TxtEmail.Text & "' WHERE IdClient = '" & TxtID.Text & "'"
        'Affichage d'une boîte de dialogue demandant la confirmation de la suppression
        reponse = MsgBox("Voulez-vous vraiment modifier ce Client ?", vbYesNo, "Modification")
        'Si l'utilisateur clique sur Oui
        If reponse = vbYes Then
            'Affichage d'un message indiquant que la suppression est effectuée
            MsgBox("Modification effectuée !", , "Modification")
            'Association de la requête SQL à l'objet commande
            cmd.CommandText = strSQL
            'Exécution de la requête SQL de suppression
            cmd.ExecuteNonQuery()
        Else
            'Affichage d'un message indiquant que la suppression a été annulée
            MsgBox("Modification non effectuée !")
        End If

        cnn.Close()
    End Sub

End Class