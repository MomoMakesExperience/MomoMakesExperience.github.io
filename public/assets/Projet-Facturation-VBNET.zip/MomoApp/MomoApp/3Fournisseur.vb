﻿'Inclusion de Références'
Imports System
Imports System.Data
Imports System.Data.OleDb
Imports Microsoft.Office.Interop

Public Class PFournisseur

    'Declaration de variables'
    Public cnn As OleDbConnection 'connexion a la Base de données'
    Public cmd As OleDbCommand 'Pour les requetes SQL'
    Public dtr As OleDbDataReader 'Lecteur de données'
    Private strSQL, strConn As String
    Public dta As OleDbDataAdapter 'Pour recupèrer les données modifier inserer entre la base et Dataset'
    Private cmb As OleDbCommandBuilder

    Private Sub TsFournisseur_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TsFournisseur.Click
        Me.Show()
    End Sub

    Private Sub TsClient_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TsClient.Click
        PClient.Show()
    End Sub

    Private Sub TsCommande_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TsCommande.Click
        PCommande.Show()
    End Sub

    Private Sub TsProduit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TsProduit.Click
        Produit.Show()
    End Sub

    Private Sub TsFacturation_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TsFacturation.Click
        Facturation.Show()
    End Sub

    'Procédure exécutée au chargement du formulaire pour initialiser et afficher les données'
    Private Sub Form3_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: cette ligne de code charge les données dans la table 'FournDataSet.Fournisseur'. Vous pouvez la déplacer ou la supprimer selon vos besoins.
        Me.FournisseurTableAdapter.Fill(Me.FournDataSet.Fournisseur)
    End Sub

    'Procédure pour voir le précédent'
    Private Sub BtnPrecedent_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnPrecedent.Click
        FournBindingSource.MovePrevious()
    End Sub

    'Procédure pour voir le suivant'
    Private Sub BtnSuivant_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnSuivant.Click
        FournBindingSource.MoveNext()
    End Sub

    'Procédure pour extraire les données et les afficher dans Excel'
    Private Sub BtnExcel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnExcel.Click
        'Connexion a la base je lui donne le nom de la base et la machine va la trouver'
        Dim cnn As New OleDbConnection("Provider = Microsoft.Jet.OleDb.4.0; Data Source = " & Application.StartupPath & "\Fournisseur.mdb")
        'Execution de la commande SQL'
        Dim cmd As New OleDbCommand("SELECT * FROM Fournisseur", cnn)
        'connexion a la base'
        cnn.Open()
        'Execution de la commande'
        Dim dtr As OleDbDataReader = cmd.ExecuteReader
        'Declaration variable pour acces a excel'
        Dim VarExcel As New Excel.Application
        'Pour que i commence a partir de la ligne 2 car la ligne 1 y a les attribut de ma table'
        Dim i As Integer
        i = 2
        VarExcel.Visible = True
        VarExcel.Workbooks.Add()
        'Pour l'acces aux champs via colonne excel'
        VarExcel.Range("A1").Value = "IdFournisseur"
        VarExcel.Range("B1").Value = "Nom"
        VarExcel.Range("C1").Value = "Prénom"
        VarExcel.Range("D1").Value = "Adresse"
        VarExcel.Range("E1").Value = "Téléphone"
        VarExcel.Range("F1").Value = "CodePostal"
        VarExcel.Range("G1").Value = "Email"
        VarExcel.Range("H1").Value = "Entreprise"
        'Pour parcourir les infos de la meme ligne'
        While dtr.Read
            VarExcel.Range("A" & i).Value = dtr("IdFournisseur")
            VarExcel.Range("B" & i).Value = dtr("Nom")
            VarExcel.Range("C" & i).Value = dtr("Prénom")
            VarExcel.Range("D" & i).Value = dtr("Adresse")
            VarExcel.Range("E" & i).Value = dtr("Téléphone")
            VarExcel.Range("F" & i).Value = dtr("CodePostal")
            VarExcel.Range("G" & i).Value = dtr("Email")
            VarExcel.Range("H" & i).Value = dtr("Entreprise")
            i += 1 'Pour passer a la ligne suivante'
        End While
    End Sub

    'On veut faire une extraction de données'
    Private Sub BtnRecherche_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnRecherche.Click
        Dim cnn As New OleDbConnection("Provider = Microsoft.Jet.OleDb.4.0; Data Source = " & Application.StartupPath & "\Fournisseur.mdb")
        'Si on a une zone de texte on met les apostrophes sinon on ne met pas'
        Dim cmd As New OleDbCommand("SELECT * FROM Fournisseur WHERE idFournisseur = '" & TxtID.Text & "'", cnn)
        'Ouverture de la connection'
        cnn.Open()
        'Execution de la commande'
        Dim dtr As OleDbDataReader = cmd.ExecuteReader
        'Condition de Lecture'
        If dtr.Read() Then
            MessageBox.Show("Il existe un fournisseur sur ce ID")
            'On rempli les infos de la base dans le formulaire'
            TxtID.Text = dtr(0).ToString
            TxtNom.Text = dtr(1).ToString
            TxtPrenom.Text = dtr(2).ToString
            TxtAdd.Text = dtr(3).ToString
            TxtTel.Text = dtr(4).ToString
            TxtCP.Text = dtr(5).ToString
            TxtEmail.Text = dtr(6).ToString
            TxtEnt.Text = dtr(7).ToString
        Else
            'Message d erreurs'
            MessageBox.Show("Il existe aucun fournisseur sur ce ID")
            TxtID.Clear()
            TxtID.Focus()
        End If
    End Sub

    Private Sub BtnEffacer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnEffacer.Click
        Me.TxtID.ResetText()
        Me.TxtNom.ResetText()
        Me.TxtPrenom.ResetText()
        Me.TxtAdd.ResetText()
        Me.TxtTel.ResetText()
        Me.TxtCP.ResetText()
        Me.TxtEmail.ResetText()
        Me.TxtEnt.ResetText()
    End Sub

    'Procédure pour supprimer un fournisseur de la base de données
    Private Sub BtnSupprimer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnSupprimer.Click
        'Construction de la chaine de connexion vers la base de données Access
        strConn = "Provider = Microsoft.Jet.OleDb.4.0; Data Source = " & Application.StartupPath & "\Fournisseur.mdb"
        'Création de l'objet de connexion à la base de données
        cnn = New OleDbConnection()
        'Association de la chaine de connexion à l'objet connexion
        cnn.ConnectionString = strConn
        'Ouverture de la connexion à la base de données
        cnn.Open()
        'Création de l'objet commande qui permettra d'exécuter la requête SQL
        cmd = cnn.CreateCommand
        'Indication que la commande à exécuter est une requête SQL écrite en texte
        cmd.CommandType = CommandType.Text
        'Déclaration d'une variable pour récupérer la réponse de l'utilisateur
        Dim reponse As String
        'Création de la requête SQL permettant de supprimer le fournisseur correspondant à l'identifiant saisi
        strSQL = "DELETE FROM Fournisseur WHERE idFournisseur = '" & TxtID.Text & "'"
        'Affichage d'une boîte de dialogue demandant la confirmation de la suppression
        reponse = MsgBox("Voulez-vous vraiment supprimer cet enregistrement ?", vbYesNo, "Suppression")
        'Si l'utilisateur clique sur Oui
        If reponse = vbYes Then
            'Affichage d'un message indiquant que la suppression est effectuée
            MsgBox("Suppression effectuée !", , "Suppression")
            'Association de la requête SQL à l'objet commande
            cmd.CommandText = strSQL
            'Exécution de la requête SQL de suppression
            cmd.ExecuteNonQuery()
        Else
            'Affichage d'un message indiquant que la suppression a été annulée
            MsgBox("Suppression non effectuée !")
        End If
        'Effacement du contenu des zones de texte
        Me.TxtID.ResetText()
        Me.TxtNom.ResetText()
        Me.TxtPrenom.ResetText()
        Me.TxtAdd.ResetText()
        Me.TxtTel.ResetText()
        Me.TxtCP.ResetText()
        Me.TxtEmail.ResetText()
        Me.TxtEnt.ResetText()
        cnn.Close()
    End Sub

    Private Sub BtnAjouter1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnAjouter1.Click
        'Connexion a la base je lui donne le nom de la base et la machine va la trouver'
        Dim cnn As New OleDbConnection("Provider = Microsoft.Jet.OleDb.4.0; Data Source = " & Application.StartupPath & "\Fournisseur.mdb")
        'Si on a une zone de texte on met les apostrophes sinon on ne met pas'
        Dim cmd As New OleDbCommand("SELECT * FROM Fournisseur WHERE idFournisseur = '" & TxtID.Text & "'", cnn)
        'Ouverture de la connection'
        cnn.Open()
        'Lecture des données'
        Dim dtr As OleDbDataReader = cmd.ExecuteReader
        'Préparation des données à recupèrer'
        Dim dta As New OleDbDataAdapter(cmd)
        'Stockage des données en mémoire'
        Dim dts As New DataSet
        If dtr.Read() Then
            MessageBox.Show("Ce fournisseur existe déjà !")
            'Effacement des zones de textes et Renvoie du curseur au niveau de la zone de texte du ID'
            TxtID.Clear()
            TxtID.Focus()
            TxtNom.Clear()
            TxtPrenom.Clear()
            TxtAdd.Clear()
            TxtTel.Clear()
            TxtCP.Clear()
            TxtEmail.Clear()
            TxtEnt.Clear()
        Else
            dtr.Close()
            'C'est une methode qui nous permet de remplir notre DataSet oubien notre Table : Fournisseur'
            dta.Fill(dts, "Fournisseur")
            'Ajout d une nouvelle ligne dans ma table Fournisseur'
            dts.Tables("Fournisseur").Rows.Add(New Object() {TxtID.Text, TxtNom.Text, TxtPrenom.Text, TxtAdd.Text, TxtTel.Text, TxtCP.Text, TxtEmail.Text, TxtEnt.Text})
            'Nous permet de créer des requetes SQL (INSERT, UPDATE, DELETE...) et complete le dataAdapter la on a deja la requete donc il modifie juste la table'
            'Ne pas oublier que le DataAdapter dta a la valeur de cmd '
            Dim cmb As New OleDbCommandBuilder(dta)
            dta.Update(dts, "Fournisseur")
            MessageBox.Show("Fournisseur Ajouté !")
            TxtID.Clear()
            TxtID.Focus()
            TxtNom.Clear()
            TxtPrenom.Clear()
            TxtAdd.Clear()
            TxtTel.Clear()
            TxtCP.Clear()
            TxtEmail.Clear()
            TxtEnt.Clear()

            'Fermeture de la connexion'
            cnn.Close()
        End If
    End Sub

    Private Sub BtnModifier_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnModifier.Click
        'Try pour qu'il m'envoie un message lorsquil ya erreur'
        Try
            'Construction de la chaine de connexion vers la base de données Access
            strConn = "Provider = Microsoft.Jet.OleDb.4.0; Data Source = " & Application.StartupPath & "\Fournisseur.mdb"
            'Création de l'objet de connexion à la base de données
            cnn = New OleDbConnection()
            'Association de la chaine de connexion à l'objet connexion
            cnn.ConnectionString = strConn
            'Ouverture de la connexion à la base de données
            cnn.Open()
            'Création de l'objet commande qui permettra d'exécuter la requête SQL
            cmd = cnn.CreateCommand
            'Indication que la commande à exécuter est une requête SQL écrite en texte
            cmd.CommandType = CommandType.Text
            'Déclaration d'une variable pour récupérer la réponse de l'utilisateur
            Dim reponse As String
            'Création de la requête SQL permettant de supprimer le fournisseur correspondant à l'identifiant saisi
            strSQL = "UPDATE Fournisseur SET Nom = '" & TxtNom.Text & "', Prénom = '" & TxtPrenom.Text & "', Adresse = '" & TxtAdd.Text & "', Téléphone = '" & TxtTel.Text & "', CodePostal = '" & TxtCP.Text & "', Email = '" & TxtEmail.Text & "', Entreprise = '" & TxtEnt.Text & "' WHERE IdFournisseur = '" & TxtID.Text & "'"
            'Affichage d'une boîte de dialogue demandant la confirmation de la suppression
            reponse = MsgBox("Voulez-vous vraiment modifier ce fournisseur ?", vbYesNo, "Ajout")
            'Si l'utilisateur clique sur Oui
            If reponse = vbYes Then
                'Affichage d'un message indiquant que la suppression est effectuée
                MsgBox("Modification effectuée !", , "Modification")
                'Association de la requête SQL à l'objet commande
                cmd.CommandText = strSQL
                'Exécution de la requête SQL de suppression
                cmd.ExecuteNonQuery()
            Else
                'Affichage d'un message indiquant que la suppression a été annulée
                MsgBox("Modification non effectuée !")
            End If
        Catch ex As Exception
            cnn.Close()
        End Try
    End Sub

End Class

