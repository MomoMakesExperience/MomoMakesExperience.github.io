﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PFournisseur
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(PFournisseur))
        Me.TxtID = New System.Windows.Forms.TextBox()
        Me.FournBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.FournDataSet = New WindowsApplication1.FournDataSet()
        Me.TxtNom = New System.Windows.Forms.TextBox()
        Me.TxtPrenom = New System.Windows.Forms.TextBox()
        Me.TxtAdd = New System.Windows.Forms.TextBox()
        Me.TxtTel = New System.Windows.Forms.TextBox()
        Me.TxtCP = New System.Windows.Forms.TextBox()
        Me.TxtEmail = New System.Windows.Forms.TextBox()
        Me.TxtEnt = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.FournisseurTableAdapter = New WindowsApplication1.FournDataSetTableAdapters.FournisseurTableAdapter()
        Me.BtnPrecedent = New System.Windows.Forms.Button()
        Me.BtnSuivant = New System.Windows.Forms.Button()
        Me.BtnExcel = New System.Windows.Forms.Button()
        Me.BtnRecherche = New System.Windows.Forms.Button()
        Me.BtnEffacer = New System.Windows.Forms.Button()
        Me.BtnSupprimer = New System.Windows.Forms.Button()
        Me.BtnAjouter1 = New System.Windows.Forms.Button()
        Me.BtnModifier = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.TsFournisseur = New System.Windows.Forms.ToolStripMenuItem()
        Me.TsClient = New System.Windows.Forms.ToolStripMenuItem()
        Me.TsCommande = New System.Windows.Forms.ToolStripMenuItem()
        Me.TsProduit = New System.Windows.Forms.ToolStripMenuItem()
        Me.TsFacturation = New System.Windows.Forms.ToolStripMenuItem()
        CType(Me.FournBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FournDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TxtID
        '
        Me.TxtID.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.FournBindingSource, "IdFournisseur", True))
        Me.TxtID.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtID.Location = New System.Drawing.Point(230, 138)
        Me.TxtID.Name = "TxtID"
        Me.TxtID.Size = New System.Drawing.Size(385, 42)
        Me.TxtID.TabIndex = 0
        '
        'FournBindingSource
        '
        Me.FournBindingSource.DataMember = "Fournisseur"
        Me.FournBindingSource.DataSource = Me.FournDataSet
        '
        'FournDataSet
        '
        Me.FournDataSet.DataSetName = "FournDataSet"
        Me.FournDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TxtNom
        '
        Me.TxtNom.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.FournBindingSource, "Nom", True))
        Me.TxtNom.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtNom.Location = New System.Drawing.Point(230, 199)
        Me.TxtNom.Name = "TxtNom"
        Me.TxtNom.Size = New System.Drawing.Size(385, 42)
        Me.TxtNom.TabIndex = 1
        '
        'TxtPrenom
        '
        Me.TxtPrenom.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.FournBindingSource, "Prénom", True))
        Me.TxtPrenom.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtPrenom.Location = New System.Drawing.Point(230, 262)
        Me.TxtPrenom.Name = "TxtPrenom"
        Me.TxtPrenom.Size = New System.Drawing.Size(385, 42)
        Me.TxtPrenom.TabIndex = 2
        '
        'TxtAdd
        '
        Me.TxtAdd.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.FournBindingSource, "Adresse", True))
        Me.TxtAdd.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtAdd.Location = New System.Drawing.Point(230, 329)
        Me.TxtAdd.Name = "TxtAdd"
        Me.TxtAdd.Size = New System.Drawing.Size(385, 42)
        Me.TxtAdd.TabIndex = 3
        '
        'TxtTel
        '
        Me.TxtTel.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.FournBindingSource, "Téléphone", True))
        Me.TxtTel.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtTel.Location = New System.Drawing.Point(230, 398)
        Me.TxtTel.Name = "TxtTel"
        Me.TxtTel.Size = New System.Drawing.Size(385, 42)
        Me.TxtTel.TabIndex = 4
        '
        'TxtCP
        '
        Me.TxtCP.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.FournBindingSource, "CodePostal", True))
        Me.TxtCP.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtCP.Location = New System.Drawing.Point(230, 463)
        Me.TxtCP.Name = "TxtCP"
        Me.TxtCP.Size = New System.Drawing.Size(385, 42)
        Me.TxtCP.TabIndex = 5
        '
        'TxtEmail
        '
        Me.TxtEmail.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.FournBindingSource, "Email", True))
        Me.TxtEmail.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtEmail.Location = New System.Drawing.Point(230, 533)
        Me.TxtEmail.Name = "TxtEmail"
        Me.TxtEmail.Size = New System.Drawing.Size(385, 42)
        Me.TxtEmail.TabIndex = 6
        '
        'TxtEnt
        '
        Me.TxtEnt.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.FournBindingSource, "Entreprise", True))
        Me.TxtEnt.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtEnt.Location = New System.Drawing.Point(230, 594)
        Me.TxtEnt.Name = "TxtEnt"
        Me.TxtEnt.Size = New System.Drawing.Size(385, 42)
        Me.TxtEnt.TabIndex = 7
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(12, 138)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(190, 34)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "IdFournisseur"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.Location = New System.Drawing.Point(119, 199)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(80, 34)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "Nom"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Location = New System.Drawing.Point(83, 262)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(119, 34)
        Me.Label3.TabIndex = 10
        Me.Label3.Text = "Prénom"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label4.Location = New System.Drawing.Point(76, 329)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(123, 34)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "Adresse"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label5.Location = New System.Drawing.Point(41, 398)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(158, 34)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "Téléphone"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label6.Location = New System.Drawing.Point(32, 466)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(170, 34)
        Me.Label6.TabIndex = 13
        Me.Label6.Text = "CodePostal"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label7.Location = New System.Drawing.Point(105, 533)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(88, 34)
        Me.Label7.TabIndex = 14
        Me.Label7.Text = "Email"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label8.Location = New System.Drawing.Point(47, 594)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(146, 34)
        Me.Label8.TabIndex = 15
        Me.Label8.Text = "Entreprise"
        '
        'FournisseurTableAdapter
        '
        Me.FournisseurTableAdapter.ClearBeforeFill = True
        '
        'BtnPrecedent
        '
        Me.BtnPrecedent.BackColor = System.Drawing.SystemColors.Highlight
        Me.BtnPrecedent.Font = New System.Drawing.Font("Century Gothic", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnPrecedent.ForeColor = System.Drawing.SystemColors.Control
        Me.BtnPrecedent.Location = New System.Drawing.Point(13, 568)
        Me.BtnPrecedent.Name = "BtnPrecedent"
        Me.BtnPrecedent.Size = New System.Drawing.Size(113, 97)
        Me.BtnPrecedent.TabIndex = 17
        Me.BtnPrecedent.Text = "◄"
        Me.BtnPrecedent.UseVisualStyleBackColor = False
        '
        'BtnSuivant
        '
        Me.BtnSuivant.BackColor = System.Drawing.SystemColors.Highlight
        Me.BtnSuivant.Font = New System.Drawing.Font("Century Gothic", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSuivant.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.BtnSuivant.Location = New System.Drawing.Point(139, 568)
        Me.BtnSuivant.Name = "BtnSuivant"
        Me.BtnSuivant.Size = New System.Drawing.Size(114, 97)
        Me.BtnSuivant.TabIndex = 18
        Me.BtnSuivant.Text = "►"
        Me.BtnSuivant.UseVisualStyleBackColor = False
        '
        'BtnExcel
        '
        Me.BtnExcel.BackColor = System.Drawing.SystemColors.Highlight
        Me.BtnExcel.Font = New System.Drawing.Font("Century Gothic", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnExcel.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.BtnExcel.Location = New System.Drawing.Point(13, 242)
        Me.BtnExcel.Name = "BtnExcel"
        Me.BtnExcel.Size = New System.Drawing.Size(240, 81)
        Me.BtnExcel.TabIndex = 19
        Me.BtnExcel.Text = "Automation"
        Me.BtnExcel.UseVisualStyleBackColor = False
        '
        'BtnRecherche
        '
        Me.BtnRecherche.BackColor = System.Drawing.SystemColors.Highlight
        Me.BtnRecherche.Font = New System.Drawing.Font("Century Gothic", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnRecherche.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.BtnRecherche.Location = New System.Drawing.Point(13, 487)
        Me.BtnRecherche.Name = "BtnRecherche"
        Me.BtnRecherche.Size = New System.Drawing.Size(241, 75)
        Me.BtnRecherche.TabIndex = 20
        Me.BtnRecherche.Text = "Recherche"
        Me.BtnRecherche.UseVisualStyleBackColor = False
        '
        'BtnEffacer
        '
        Me.BtnEffacer.BackColor = System.Drawing.SystemColors.Highlight
        Me.BtnEffacer.Font = New System.Drawing.Font("Century Gothic", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnEffacer.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.BtnEffacer.Location = New System.Drawing.Point(11, 167)
        Me.BtnEffacer.Name = "BtnEffacer"
        Me.BtnEffacer.Size = New System.Drawing.Size(241, 69)
        Me.BtnEffacer.TabIndex = 21
        Me.BtnEffacer.Text = "Effacer"
        Me.BtnEffacer.UseVisualStyleBackColor = False
        '
        'BtnSupprimer
        '
        Me.BtnSupprimer.BackColor = System.Drawing.SystemColors.Highlight
        Me.BtnSupprimer.Font = New System.Drawing.Font("Century Gothic", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSupprimer.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.BtnSupprimer.Location = New System.Drawing.Point(12, 411)
        Me.BtnSupprimer.Name = "BtnSupprimer"
        Me.BtnSupprimer.Size = New System.Drawing.Size(241, 70)
        Me.BtnSupprimer.TabIndex = 22
        Me.BtnSupprimer.Text = "Supprimer"
        Me.BtnSupprimer.UseVisualStyleBackColor = False
        '
        'BtnAjouter1
        '
        Me.BtnAjouter1.BackColor = System.Drawing.SystemColors.Highlight
        Me.BtnAjouter1.Font = New System.Drawing.Font("Century Gothic", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnAjouter1.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.BtnAjouter1.Location = New System.Drawing.Point(11, 87)
        Me.BtnAjouter1.Name = "BtnAjouter1"
        Me.BtnAjouter1.Size = New System.Drawing.Size(242, 74)
        Me.BtnAjouter1.TabIndex = 24
        Me.BtnAjouter1.Text = "Ajouter"
        Me.BtnAjouter1.UseVisualStyleBackColor = False
        '
        'BtnModifier
        '
        Me.BtnModifier.BackColor = System.Drawing.SystemColors.Highlight
        Me.BtnModifier.Font = New System.Drawing.Font("Century Gothic", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnModifier.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.BtnModifier.Location = New System.Drawing.Point(12, 329)
        Me.BtnModifier.Name = "BtnModifier"
        Me.BtnModifier.Size = New System.Drawing.Size(242, 76)
        Me.BtnModifier.TabIndex = 25
        Me.BtnModifier.Text = "Modifier"
        Me.BtnModifier.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.SystemColors.Highlight
        Me.Button1.Font = New System.Drawing.Font("Century Gothic", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.Button1.Location = New System.Drawing.Point(230, 24)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(385, 77)
        Me.Button1.TabIndex = 55
        Me.Button1.Text = "FOURNISSEURS"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.SystemColors.HighlightText
        Me.Panel3.Controls.Add(Me.Label15)
        Me.Panel3.Controls.Add(Me.BtnModifier)
        Me.Panel3.Controls.Add(Me.BtnAjouter1)
        Me.Panel3.Controls.Add(Me.BtnExcel)
        Me.Panel3.Controls.Add(Me.BtnRecherche)
        Me.Panel3.Controls.Add(Me.BtnSuivant)
        Me.Panel3.Controls.Add(Me.BtnPrecedent)
        Me.Panel3.Controls.Add(Me.BtnSupprimer)
        Me.Panel3.Controls.Add(Me.BtnEffacer)
        Me.Panel3.Location = New System.Drawing.Point(719, 34)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(263, 687)
        Me.Panel3.TabIndex = 56
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Century Gothic", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.SystemColors.Highlight
        Me.Label15.Location = New System.Drawing.Point(46, 24)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(157, 43)
        Me.Label15.TabIndex = 53
        Me.Label15.Text = "Boutons"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Panel1.Controls.Add(Me.TxtID)
        Me.Panel1.Controls.Add(Me.TxtNom)
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Controls.Add(Me.TxtPrenom)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.TxtAdd)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.TxtTel)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.TxtCP)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.TxtEmail)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.TxtEnt)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Location = New System.Drawing.Point(0, 34)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(713, 684)
        Me.Panel1.TabIndex = 57
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.SystemColors.Highlight
        Me.MenuStrip1.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TsFournisseur, Me.TsClient, Me.TsCommande, Me.TsProduit, Me.TsFacturation})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(982, 31)
        Me.MenuStrip1.TabIndex = 58
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'TsFournisseur
        '
        Me.TsFournisseur.ForeColor = System.Drawing.SystemColors.Window
        Me.TsFournisseur.Name = "TsFournisseur"
        Me.TsFournisseur.Size = New System.Drawing.Size(129, 27)
        Me.TsFournisseur.Text = "Fournisseur"
        '
        'TsClient
        '
        Me.TsClient.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TsClient.ForeColor = System.Drawing.SystemColors.Window
        Me.TsClient.Name = "TsClient"
        Me.TsClient.Size = New System.Drawing.Size(79, 27)
        Me.TsClient.Text = "Client"
        '
        'TsCommande
        '
        Me.TsCommande.ForeColor = System.Drawing.SystemColors.Window
        Me.TsCommande.Name = "TsCommande"
        Me.TsCommande.Size = New System.Drawing.Size(140, 27)
        Me.TsCommande.Text = "Commande"
        '
        'TsProduit
        '
        Me.TsProduit.ForeColor = System.Drawing.SystemColors.Window
        Me.TsProduit.Name = "TsProduit"
        Me.TsProduit.Size = New System.Drawing.Size(88, 27)
        Me.TsProduit.Text = "Produit"
        '
        'TsFacturation
        '
        Me.TsFacturation.ForeColor = System.Drawing.SystemColors.Window
        Me.TsFacturation.Name = "TsFacturation"
        Me.TsFacturation.Size = New System.Drawing.Size(131, 27)
        Me.TsFacturation.Text = "Facturation"
        '
        'PFournisseur
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(982, 718)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel3)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "PFournisseur"
        Me.Text = "Form3"
        CType(Me.FournBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FournDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TxtID As System.Windows.Forms.TextBox
    Friend WithEvents TxtNom As System.Windows.Forms.TextBox
    Friend WithEvents TxtPrenom As System.Windows.Forms.TextBox
    Friend WithEvents TxtAdd As System.Windows.Forms.TextBox
    Friend WithEvents TxtTel As System.Windows.Forms.TextBox
    Friend WithEvents TxtCP As System.Windows.Forms.TextBox
    Friend WithEvents TxtEmail As System.Windows.Forms.TextBox
    Friend WithEvents TxtEnt As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents FournDataSet As WindowsApplication1.FournDataSet
    Friend WithEvents FournBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents FournisseurTableAdapter As WindowsApplication1.FournDataSetTableAdapters.FournisseurTableAdapter
    Friend WithEvents BtnPrecedent As System.Windows.Forms.Button
    Friend WithEvents BtnSuivant As System.Windows.Forms.Button
    Friend WithEvents BtnExcel As System.Windows.Forms.Button
    Friend WithEvents BtnRecherche As System.Windows.Forms.Button
    Friend WithEvents BtnEffacer As System.Windows.Forms.Button
    Friend WithEvents BtnSupprimer As System.Windows.Forms.Button
    Friend WithEvents BtnAjouter1 As System.Windows.Forms.Button
    Friend WithEvents BtnModifier As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents TsFournisseur As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TsClient As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TsCommande As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TsProduit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TsFacturation As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label15 As System.Windows.Forms.Label
End Class
