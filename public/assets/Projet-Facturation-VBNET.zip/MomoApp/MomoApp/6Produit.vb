﻿'Inclusion de Références'
Imports System
Imports System.Data
Imports System.Data.OleDb
Imports Microsoft.Office.Interop

Public Class Produit
    'Declaration de variables'
    Public cnn As OleDbConnection 'connexion a la Base de données'
    Public cmd As OleDbCommand 'Pour les requetes SQL'
    Public dtr As OleDbDataReader 'Lecteur de données'
    Private strSQL, strConn As String
    Public dta As OleDbDataAdapter 'Pour recupèrer les données modifier inserer entre la base et Dataset'
    Private cmb As OleDbCommandBuilder

    Private Sub Form7_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: cette ligne de code charge les données dans la table 'FournDataSet.Produit'. Vous pouvez la déplacer ou la supprimer selon vos besoins.
        Me.ProduitTableAdapter.Fill(Me.FournDataSet.Produit)
    End Sub

    Private Sub TsFournisseur_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TsFournisseur.Click
        PFournisseur.Show()
    End Sub

    Private Sub TsClient_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TsClient.Click
        PClient.Show()
    End Sub

    Private Sub TsCommande_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TsCommande.Click
        PCommande.Show()
    End Sub

    Private Sub TsProduit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TsProduit.Click
        Me.Show()
    End Sub

    Private Sub TsFacturation_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TsFacturation.Click
        Facturation.Show()
    End Sub

    'Procédure pour voir le précédent'
    Private Sub BtnPrecedent_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnPrecedent.Click
        ProduitBindingSource.MovePrevious()
    End Sub

    'Procédure pour voir le suivant'
    Private Sub BtnSuivant_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnSuivant.Click
        ProduitBindingSource.MoveNext()
    End Sub

    'On veut faire une extraction de données'
    Private Sub BtnRecherche_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnRecherche.Click
        Dim cnn As New OleDbConnection("Provider = Microsoft.Jet.OleDb.4.0; Data Source = " & Application.StartupPath & "\Fournisseur.mdb")
        'Si on a une zone de texte on met les apostrophes sinon on ne met pas'
        Dim cmd As New OleDbCommand("SELECT * FROM Produit WHERE CodeProduit = '" & TxtCode.Text & "'", cnn)
        'Ouverture de la connection'
        cnn.Open()
        'Execution de la commande'
        Dim dtr As OleDbDataReader = cmd.ExecuteReader
        'Condition de Lecture'
        If dtr.Read() Then
            MessageBox.Show("Il existe un produit sur ce code")
            'On rempli les infos de la base dans le formulaire'
            TxtCode.Text = dtr(0).ToString
            TxtDesignation.Text = dtr(1).ToString
            TxtPrix.Text = dtr(2).ToString
            TxtTVA.Text = dtr(3).ToString
            TxtStock.Text = dtr(4).ToString
        Else
            'Message d erreurs'
            MessageBox.Show("Il existe aucun produit sur ce code")
            TxtCode.Clear()
            TxtCode.Focus()
        End If
    End Sub

    Private Sub BtnEffacer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnEffacer.Click
        Me.TxtCode.ResetText()
        Me.TxtDesignation.ResetText()
        Me.TxtPrix.ResetText()
        Me.TxtTVA.ResetText()
        Me.TxtStock.ResetText()
    End Sub

    'Procédure pour supprimer un fournisseur de la base de données
    Private Sub BtnSupprimer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnSupprimer.Click
        'Construction de la chaine de connexion vers la base de données Access
        strConn = "Provider = Microsoft.Jet.OleDb.4.0; Data Source = " & Application.StartupPath & "\Fournisseur.mdb"
        'Création de l'objet de connexion à la base de données
        cnn = New OleDbConnection()
        'Association de la chaine de connexion à l'objet connexion
        cnn.ConnectionString = strConn
        'Ouverture de la connexion à la base de données
        cnn.Open()
        'Création de l'objet commande qui permettra d'exécuter la requête SQL
        cmd = cnn.CreateCommand
        'Indication que la commande à exécuter est une requête SQL écrite en texte
        cmd.CommandType = CommandType.Text
        'Déclaration d'une variable pour récupérer la réponse de l'utilisateur
        Dim reponse As String
        'Création de la requête SQL permettant de supprimer le fournisseur correspondant à l'identifiant saisi
        strSQL = "DELETE FROM Produit WHERE CodeProduit = '" & TxtCode.Text & "'"
        'Affichage d'une boîte de dialogue demandant la confirmation de la suppression
        reponse = MsgBox("Voulez-vous vraiment supprimer ce produit ?", vbYesNo, "Suppression")
        'Si l'utilisateur clique sur Oui
        If reponse = vbYes Then
            'Affichage d'un message indiquant que la suppression est effectuée
            MsgBox("Suppression effectuée !", , "Suppression")
            'Association de la requête SQL à l'objet commande
            cmd.CommandText = strSQL
            'Exécution de la requête SQL de suppression
            cmd.ExecuteNonQuery()
        Else
            'Affichage d'un message indiquant que la suppression a été annulée
            MsgBox("Suppression non effectuée !")
        End If
        'Effacement du contenu des zones de texte
        Me.TxtCode.ResetText()
        Me.TxtDesignation.ResetText()
        Me.TxtPrix.ResetText()
        Me.TxtTVA.ResetText()
        Me.TxtStock.ResetText()

        cnn.Close()
    End Sub

    Private Sub BtnAjouter1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnAjouter1.Click
        'Connexion a la base je lui donne le nom de la base et la machine va la trouver'
        Dim cnn As New OleDbConnection("Provider = Microsoft.Jet.OleDb.4.0; Data Source = " & Application.StartupPath & "\Fournisseur.mdb")
        'Si on a une zone de texte on met les apostrophes sinon on ne met pas'
        Dim cmd As New OleDbCommand("SELECT * FROM Produit WHERE CodeProduit = '" & TxtCode.Text & "'", cnn)
        'Ouverture de la connection'
        cnn.Open()
        'Lecture des données'
        Dim dtr As OleDbDataReader = cmd.ExecuteReader
        'Préparation des données à recupèrer'
        Dim dta As New OleDbDataAdapter(cmd)
        'Stockage des données en mémoire'
        Dim dts As New DataSet
        If dtr.Read() Then
            MessageBox.Show("Ce produit existe déjà !")
            'Effacement des zones de textes et Renvoie du curseur au niveau de la zone de texte du ID'
            TxtCode.Clear()
            TxtDesignation.Focus()
            TxtPrix.Clear()
            TxtTVA.Clear()
            TxtStock.Clear()
        Else
            dtr.Close()
            'C'est une methode qui nous permet de remplir notre DataSet oubien notre Table : Fournisseur'
            dta.Fill(dts, "Produit")
            'Ajout d une nouvelle ligne dans ma table Fournisseur'
            dts.Tables("Produit").Rows.Add(New Object() {TxtCode.Text, TxtDesignation.Text, TxtPrix.Text, TxtTVA.Text, TxtStock.Text})
            'Nous permet de créer des requetes SQL (INSERT, UPDATE, DELETE...) et complete le dataAdapter la on a deja la requete donc il modifie juste la table'
            'Ne pas oublier que le DataAdapter dta a la valeur de cmd '
            Dim cmb As New OleDbCommandBuilder(dta)
            dta.Update(dts, "Produit")
            MessageBox.Show("Produit Ajouté !")
            TxtCode.Clear()
            TxtCode.Focus()
            TxtDesignation.Focus()
            TxtPrix.Clear()
            TxtTVA.Clear()
            TxtStock.Clear()

            'Fermeture de la connexion'
            cnn.Close()
        End If
    End Sub

    Private Sub BtnModifier_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnModifier.Click
        'Construction de la chaine de connexion vers la base de données Access
        strConn = "Provider = Microsoft.Jet.OleDb.4.0; Data Source = " & Application.StartupPath & "\Fournisseur.mdb"
        'Création de l'objet de connexion à la base de données
        cnn = New OleDbConnection()
        'Association de la chaine de connexion à l'objet connexion
        cnn.ConnectionString = strConn
        'Ouverture de la connexion à la base de données
        cnn.Open()
        'Création de l'objet commande qui permettra d'exécuter la requête SQL
        cmd = cnn.CreateCommand
        'Indication que la commande à exécuter est une requête SQL écrite en texte
        cmd.CommandType = CommandType.Text
        'Déclaration d'une variable pour récupérer la réponse de l'utilisateur
        Dim reponse As String
        'Création de la requête SQL permettant de supprimer le fournisseur correspondant à l'identifiant saisi
        strSQL = "UPDATE Produit SET Designation = '" & TxtDesignation.Text & "', PrixUnitaire  = '" & TxtPrix.Text & "', TVA = '" & TxtTVA.Text & "', Stock = '" & TxtStock.Text & "' WHERE CodeProduit = '" & TxtCode.Text & "'"
        'Affichage d'une boîte de dialogue demandant la confirmation de la suppression
        reponse = MsgBox("Voulez-vous vraiment modifier ce Produit ?", vbYesNo, "Modification")
        'Si l'utilisateur clique sur Oui
        If reponse = vbYes Then
            'Affichage d'un message indiquant que la suppression est effectuée
            MsgBox("Modification effectuée !", , "Modification")
            'Association de la requête SQL à l'objet commande
            cmd.CommandText = strSQL
            'Exécution de la requête SQL de suppression
            cmd.ExecuteNonQuery()
        Else
            'Affichage d'un message indiquant que la suppression a été annulée
            MsgBox("Modification non effectuée !")
        End If

        cnn.Close()
    End Sub

    'Procédure pour extraire les données et les afficher dans Excel'
    Private Sub BtnExcel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnExcel.Click
        'Connexion a la base je lui donne le nom de la base et la machine va la trouver'
        Dim cnn As New OleDbConnection("Provider = Microsoft.Jet.OleDb.4.0; Data Source = " & Application.StartupPath & "\Fournisseur.mdb")
        'Execution de la commande SQL'
        Dim cmd As New OleDbCommand("SELECT * FROM Produit", cnn)
        'connexion a la base'
        cnn.Open()
        'Execution de la commande'
        Dim dtr As OleDbDataReader = cmd.ExecuteReader
        'Declaration variable pour acces a excel'
        Dim VarExcel As New Excel.Application
        'Pour que i commence a partir de la ligne 2 car la ligne 1 y a les attribut de ma table'
        Dim i As Integer
        i = 2
        VarExcel.Visible = True
        VarExcel.Workbooks.Add()
        'Pour l'acces aux champs via colonne excel'
        VarExcel.Range("A1").Value = "CodeProduit"
        VarExcel.Range("B1").Value = "Designation"
        VarExcel.Range("C1").Value = "PrixUnitaire"
        VarExcel.Range("D1").Value = "TVA"
        VarExcel.Range("E1").Value = "Stock"

        'Pour parcourir les infos de la meme ligne'
        While dtr.Read
            VarExcel.Range("A" & i).Value = dtr("CodeProduit")
            VarExcel.Range("B" & i).Value = dtr("Designation")
            VarExcel.Range("C" & i).Value = dtr("PrixUnitaire")
            VarExcel.Range("D" & i).Value = dtr("TVA")
            VarExcel.Range("E" & i).Value = dtr("Stock")
            i += 1 'Pour passer a la ligne suivante'
        End While
    End Sub

    Private Sub Panel1_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Panel1.Paint

    End Sub
End Class

