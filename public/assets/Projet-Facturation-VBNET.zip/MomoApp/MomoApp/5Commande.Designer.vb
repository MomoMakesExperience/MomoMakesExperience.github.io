﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PCommande
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TxtEtat = New System.Windows.Forms.TextBox()
        Me.CommandeBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.FournDataSet = New WindowsApplication1.FournDataSet()
        Me.TxtDate = New System.Windows.Forms.TextBox()
        Me.TxtID = New System.Windows.Forms.TextBox()
        Me.TxtCommande = New System.Windows.Forms.TextBox()
        Me.BtnEffacer = New System.Windows.Forms.Button()
        Me.BtnSupprimer = New System.Windows.Forms.Button()
        Me.BtnModifier = New System.Windows.Forms.Button()
        Me.BtnAjouter = New System.Windows.Forms.Button()
        Me.BtnPrecedent = New System.Windows.Forms.Button()
        Me.BtnSuivant = New System.Windows.Forms.Button()
        Me.CommandeTableAdapter = New WindowsApplication1.FournDataSetTableAdapters.CommandeTableAdapter()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.TsFournisseur = New System.Windows.Forms.ToolStripMenuItem()
        Me.TsClient = New System.Windows.Forms.ToolStripMenuItem()
        Me.TsCommande = New System.Windows.Forms.ToolStripMenuItem()
        Me.TsProduit = New System.Windows.Forms.ToolStripMenuItem()
        Me.TsFacturation = New System.Windows.Forms.ToolStripMenuItem()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.TxtRecherche = New System.Windows.Forms.TextBox()
        Me.BtnRecherche = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        CType(Me.CommandeBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FournDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(23, 407)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(235, 34)
        Me.Label4.TabIndex = 70
        Me.Label4.Text = "Etat Commande"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(12, 326)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(250, 34)
        Me.Label3.TabIndex = 69
        Me.Label3.Text = "Date Commande"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(128, 256)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(130, 34)
        Me.Label2.TabIndex = 68
        Me.Label2.Text = "ID Client"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(33, 185)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(225, 34)
        Me.Label1.TabIndex = 67
        Me.Label1.Text = "No Commande"
        '
        'TxtEtat
        '
        Me.TxtEtat.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CommandeBindingSource, "CommandeRegle", True))
        Me.TxtEtat.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtEtat.Location = New System.Drawing.Point(275, 403)
        Me.TxtEtat.Name = "TxtEtat"
        Me.TxtEtat.Size = New System.Drawing.Size(421, 42)
        Me.TxtEtat.TabIndex = 66
        '
        'CommandeBindingSource
        '
        Me.CommandeBindingSource.DataMember = "Commande"
        Me.CommandeBindingSource.DataSource = Me.FournDataSet
        '
        'FournDataSet
        '
        Me.FournDataSet.DataSetName = "FournDataSet"
        Me.FournDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TxtDate
        '
        Me.TxtDate.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CommandeBindingSource, "DateCommande", True))
        Me.TxtDate.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtDate.Location = New System.Drawing.Point(275, 326)
        Me.TxtDate.Name = "TxtDate"
        Me.TxtDate.Size = New System.Drawing.Size(421, 42)
        Me.TxtDate.TabIndex = 65
        '
        'TxtID
        '
        Me.TxtID.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CommandeBindingSource, "IdClient", True))
        Me.TxtID.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtID.Location = New System.Drawing.Point(275, 252)
        Me.TxtID.Name = "TxtID"
        Me.TxtID.Size = New System.Drawing.Size(421, 42)
        Me.TxtID.TabIndex = 64
        '
        'TxtCommande
        '
        Me.TxtCommande.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CommandeBindingSource, "NumCommande", True))
        Me.TxtCommande.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtCommande.Location = New System.Drawing.Point(275, 181)
        Me.TxtCommande.Name = "TxtCommande"
        Me.TxtCommande.Size = New System.Drawing.Size(421, 42)
        Me.TxtCommande.TabIndex = 63
        '
        'BtnEffacer
        '
        Me.BtnEffacer.BackColor = System.Drawing.SystemColors.Highlight
        Me.BtnEffacer.Font = New System.Drawing.Font("Century Gothic", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnEffacer.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.BtnEffacer.Location = New System.Drawing.Point(17, 418)
        Me.BtnEffacer.Name = "BtnEffacer"
        Me.BtnEffacer.Size = New System.Drawing.Size(197, 105)
        Me.BtnEffacer.TabIndex = 5
        Me.BtnEffacer.Text = "Effacer"
        Me.BtnEffacer.UseVisualStyleBackColor = False
        '
        'BtnSupprimer
        '
        Me.BtnSupprimer.BackColor = System.Drawing.SystemColors.Highlight
        Me.BtnSupprimer.Font = New System.Drawing.Font("Century Gothic", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSupprimer.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.BtnSupprimer.Location = New System.Drawing.Point(17, 309)
        Me.BtnSupprimer.Name = "BtnSupprimer"
        Me.BtnSupprimer.Size = New System.Drawing.Size(197, 103)
        Me.BtnSupprimer.TabIndex = 4
        Me.BtnSupprimer.Text = "Supprimer"
        Me.BtnSupprimer.UseVisualStyleBackColor = False
        '
        'BtnModifier
        '
        Me.BtnModifier.BackColor = System.Drawing.SystemColors.Highlight
        Me.BtnModifier.Font = New System.Drawing.Font("Century Gothic", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnModifier.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.BtnModifier.Location = New System.Drawing.Point(17, 208)
        Me.BtnModifier.Name = "BtnModifier"
        Me.BtnModifier.Size = New System.Drawing.Size(197, 95)
        Me.BtnModifier.TabIndex = 3
        Me.BtnModifier.Text = "Modifier"
        Me.BtnModifier.UseVisualStyleBackColor = False
        '
        'BtnAjouter
        '
        Me.BtnAjouter.BackColor = System.Drawing.SystemColors.Highlight
        Me.BtnAjouter.Font = New System.Drawing.Font("Century Gothic", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnAjouter.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.BtnAjouter.Location = New System.Drawing.Point(17, 104)
        Me.BtnAjouter.Name = "BtnAjouter"
        Me.BtnAjouter.Size = New System.Drawing.Size(197, 98)
        Me.BtnAjouter.TabIndex = 2
        Me.BtnAjouter.Text = "Ajouter"
        Me.BtnAjouter.UseVisualStyleBackColor = False
        '
        'BtnPrecedent
        '
        Me.BtnPrecedent.BackColor = System.Drawing.SystemColors.Highlight
        Me.BtnPrecedent.Font = New System.Drawing.Font("Century Gothic", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnPrecedent.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.BtnPrecedent.Location = New System.Drawing.Point(17, 540)
        Me.BtnPrecedent.Name = "BtnPrecedent"
        Me.BtnPrecedent.Size = New System.Drawing.Size(94, 85)
        Me.BtnPrecedent.TabIndex = 3
        Me.BtnPrecedent.Text = "◄"
        Me.BtnPrecedent.UseVisualStyleBackColor = False
        '
        'BtnSuivant
        '
        Me.BtnSuivant.BackColor = System.Drawing.SystemColors.Highlight
        Me.BtnSuivant.Font = New System.Drawing.Font("Century Gothic", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSuivant.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.BtnSuivant.Location = New System.Drawing.Point(117, 540)
        Me.BtnSuivant.Name = "BtnSuivant"
        Me.BtnSuivant.Size = New System.Drawing.Size(97, 85)
        Me.BtnSuivant.TabIndex = 4
        Me.BtnSuivant.Text = "►"
        Me.BtnSuivant.UseVisualStyleBackColor = False
        '
        'CommandeTableAdapter
        '
        Me.CommandeTableAdapter.ClearBeforeFill = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.SystemColors.Highlight
        Me.MenuStrip1.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TsFournisseur, Me.TsClient, Me.TsCommande, Me.TsProduit, Me.TsFacturation})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(977, 31)
        Me.MenuStrip1.TabIndex = 6
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'TsFournisseur
        '
        Me.TsFournisseur.ForeColor = System.Drawing.SystemColors.Window
        Me.TsFournisseur.Name = "TsFournisseur"
        Me.TsFournisseur.Size = New System.Drawing.Size(129, 27)
        Me.TsFournisseur.Text = "Fournisseur"
        '
        'TsClient
        '
        Me.TsClient.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TsClient.ForeColor = System.Drawing.SystemColors.Window
        Me.TsClient.Name = "TsClient"
        Me.TsClient.Size = New System.Drawing.Size(79, 27)
        Me.TsClient.Text = "Client"
        '
        'TsCommande
        '
        Me.TsCommande.ForeColor = System.Drawing.SystemColors.Window
        Me.TsCommande.Name = "TsCommande"
        Me.TsCommande.Size = New System.Drawing.Size(140, 27)
        Me.TsCommande.Text = "Commande"
        '
        'TsProduit
        '
        Me.TsProduit.ForeColor = System.Drawing.SystemColors.Window
        Me.TsProduit.Name = "TsProduit"
        Me.TsProduit.Size = New System.Drawing.Size(88, 27)
        Me.TsProduit.Text = "Produit"
        '
        'TsFacturation
        '
        Me.TsFacturation.ForeColor = System.Drawing.SystemColors.Window
        Me.TsFacturation.Name = "TsFacturation"
        Me.TsFacturation.Size = New System.Drawing.Size(131, 27)
        Me.TsFacturation.Text = "Facturation"
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Panel3.Controls.Add(Me.BtnEffacer)
        Me.Panel3.Controls.Add(Me.Label8)
        Me.Panel3.Controls.Add(Me.BtnSupprimer)
        Me.Panel3.Controls.Add(Me.BtnSuivant)
        Me.Panel3.Controls.Add(Me.BtnModifier)
        Me.Panel3.Controls.Add(Me.BtnAjouter)
        Me.Panel3.Controls.Add(Me.BtnPrecedent)
        Me.Panel3.Location = New System.Drawing.Point(739, 34)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(238, 690)
        Me.Panel3.TabIndex = 56
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label8.Font = New System.Drawing.Font("Century Gothic", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label8.Location = New System.Drawing.Point(43, 42)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(138, 38)
        Me.Label8.TabIndex = 52
        Me.Label8.Text = "Boutons"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Panel2.Controls.Add(Me.Label5)
        Me.Panel2.Controls.Add(Me.TxtRecherche)
        Me.Panel2.Controls.Add(Me.BtnRecherche)
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Controls.Add(Me.Button8)
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Controls.Add(Me.TxtCommande)
        Me.Panel2.Controls.Add(Me.TxtEtat)
        Me.Panel2.Controls.Add(Me.TxtDate)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.TxtID)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Location = New System.Drawing.Point(0, 34)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(733, 690)
        Me.Panel2.TabIndex = 57
        '
        'Button8
        '
        Me.Button8.BackColor = System.Drawing.SystemColors.Highlight
        Me.Button8.Font = New System.Drawing.Font("Century Gothic", 28.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button8.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.Button8.Location = New System.Drawing.Point(275, 42)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(421, 79)
        Me.Button8.TabIndex = 54
        Me.Button8.Text = "COMMANDES"
        Me.Button8.UseVisualStyleBackColor = False
        '
        'TxtRecherche
        '
        Me.TxtRecherche.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtRecherche.Location = New System.Drawing.Point(275, 507)
        Me.TxtRecherche.Name = "TxtRecherche"
        Me.TxtRecherche.Size = New System.Drawing.Size(317, 42)
        Me.TxtRecherche.TabIndex = 73
        '
        'BtnRecherche
        '
        Me.BtnRecherche.BackColor = System.Drawing.SystemColors.Highlight
        Me.BtnRecherche.Font = New System.Drawing.Font("Century Gothic", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnRecherche.ForeColor = System.Drawing.Color.White
        Me.BtnRecherche.Location = New System.Drawing.Point(598, 503)
        Me.BtnRecherche.Name = "BtnRecherche"
        Me.BtnRecherche.Size = New System.Drawing.Size(82, 49)
        Me.BtnRecherche.TabIndex = 72
        Me.BtnRecherche.Text = "🔍"
        Me.BtnRecherche.UseVisualStyleBackColor = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(94, 511)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(164, 34)
        Me.Label5.TabIndex = 74
        Me.Label5.Text = "Recherche"
        '
        'PCommande
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(977, 724)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Name = "PCommande"
        Me.Text = "Form8"
        CType(Me.CommandeBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FournDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TxtEtat As System.Windows.Forms.TextBox
    Friend WithEvents TxtDate As System.Windows.Forms.TextBox
    Friend WithEvents TxtID As System.Windows.Forms.TextBox
    Friend WithEvents TxtCommande As System.Windows.Forms.TextBox
    Friend WithEvents BtnAjouter As System.Windows.Forms.Button
    Friend WithEvents BtnEffacer As System.Windows.Forms.Button
    Friend WithEvents BtnSupprimer As System.Windows.Forms.Button
    Friend WithEvents BtnModifier As System.Windows.Forms.Button
    Friend WithEvents BtnPrecedent As System.Windows.Forms.Button
    Friend WithEvents BtnSuivant As System.Windows.Forms.Button
    Friend WithEvents FournDataSet As WindowsApplication1.FournDataSet
    Friend WithEvents CommandeBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents CommandeTableAdapter As WindowsApplication1.FournDataSetTableAdapters.CommandeTableAdapter
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents TsFournisseur As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TsClient As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TsCommande As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TsProduit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TsFacturation As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents TxtRecherche As System.Windows.Forms.TextBox
    Friend WithEvents BtnRecherche As System.Windows.Forms.Button
End Class
