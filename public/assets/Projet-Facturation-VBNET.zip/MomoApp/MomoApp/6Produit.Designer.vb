﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Produit
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.BtnModifier = New System.Windows.Forms.Button()
        Me.BtnAjouter1 = New System.Windows.Forms.Button()
        Me.BtnSupprimer = New System.Windows.Forms.Button()
        Me.BtnEffacer = New System.Windows.Forms.Button()
        Me.BtnRecherche = New System.Windows.Forms.Button()
        Me.BtnExcel = New System.Windows.Forms.Button()
        Me.BtnSuivant = New System.Windows.Forms.Button()
        Me.BtnPrecedent = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TxtStock = New System.Windows.Forms.TextBox()
        Me.ProduitBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.FournDataSet = New WindowsApplication1.FournDataSet()
        Me.TxtTVA = New System.Windows.Forms.TextBox()
        Me.TxtPrix = New System.Windows.Forms.TextBox()
        Me.TxtDesignation = New System.Windows.Forms.TextBox()
        Me.TxtCode = New System.Windows.Forms.TextBox()
        Me.ProduitTableAdapter = New WindowsApplication1.FournDataSetTableAdapters.ProduitTableAdapter()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.TsFournisseur = New System.Windows.Forms.ToolStripMenuItem()
        Me.TsClient = New System.Windows.Forms.ToolStripMenuItem()
        Me.TsCommande = New System.Windows.Forms.ToolStripMenuItem()
        Me.TsProduit = New System.Windows.Forms.ToolStripMenuItem()
        Me.TsFacturation = New System.Windows.Forms.ToolStripMenuItem()
        CType(Me.ProduitBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FournDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'BtnModifier
        '
        Me.BtnModifier.BackColor = System.Drawing.SystemColors.Highlight
        Me.BtnModifier.Font = New System.Drawing.Font("Century Gothic", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnModifier.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.BtnModifier.ImageAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.BtnModifier.Location = New System.Drawing.Point(21, 335)
        Me.BtnModifier.Name = "BtnModifier"
        Me.BtnModifier.Size = New System.Drawing.Size(205, 87)
        Me.BtnModifier.TabIndex = 75
        Me.BtnModifier.Text = "Modifier"
        Me.BtnModifier.UseVisualStyleBackColor = False
        '
        'BtnAjouter1
        '
        Me.BtnAjouter1.BackColor = System.Drawing.SystemColors.Highlight
        Me.BtnAjouter1.Font = New System.Drawing.Font("Century Gothic", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnAjouter1.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.BtnAjouter1.ImageAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.BtnAjouter1.Location = New System.Drawing.Point(21, 65)
        Me.BtnAjouter1.Name = "BtnAjouter1"
        Me.BtnAjouter1.Size = New System.Drawing.Size(205, 74)
        Me.BtnAjouter1.TabIndex = 74
        Me.BtnAjouter1.Text = "Ajouter"
        Me.BtnAjouter1.UseVisualStyleBackColor = False
        '
        'BtnSupprimer
        '
        Me.BtnSupprimer.BackColor = System.Drawing.SystemColors.Highlight
        Me.BtnSupprimer.Font = New System.Drawing.Font("Century Gothic", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSupprimer.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.BtnSupprimer.ImageAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.BtnSupprimer.Location = New System.Drawing.Point(19, 428)
        Me.BtnSupprimer.Name = "BtnSupprimer"
        Me.BtnSupprimer.Size = New System.Drawing.Size(204, 77)
        Me.BtnSupprimer.TabIndex = 72
        Me.BtnSupprimer.Text = "Supprimer"
        Me.BtnSupprimer.UseVisualStyleBackColor = False
        '
        'BtnEffacer
        '
        Me.BtnEffacer.BackColor = System.Drawing.SystemColors.Highlight
        Me.BtnEffacer.Font = New System.Drawing.Font("Century Gothic", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnEffacer.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.BtnEffacer.ImageAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.BtnEffacer.Location = New System.Drawing.Point(22, 150)
        Me.BtnEffacer.Name = "BtnEffacer"
        Me.BtnEffacer.Size = New System.Drawing.Size(204, 74)
        Me.BtnEffacer.TabIndex = 71
        Me.BtnEffacer.Text = "Effacer"
        Me.BtnEffacer.UseVisualStyleBackColor = False
        '
        'BtnRecherche
        '
        Me.BtnRecherche.BackColor = System.Drawing.SystemColors.Highlight
        Me.BtnRecherche.Font = New System.Drawing.Font("Century Gothic", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnRecherche.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.BtnRecherche.ImageAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.BtnRecherche.Location = New System.Drawing.Point(21, 511)
        Me.BtnRecherche.Name = "BtnRecherche"
        Me.BtnRecherche.Size = New System.Drawing.Size(204, 82)
        Me.BtnRecherche.TabIndex = 70
        Me.BtnRecherche.Text = "Recherche"
        Me.BtnRecherche.UseVisualStyleBackColor = False
        '
        'BtnExcel
        '
        Me.BtnExcel.BackColor = System.Drawing.SystemColors.Highlight
        Me.BtnExcel.Font = New System.Drawing.Font("Century Gothic", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnExcel.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.BtnExcel.ImageAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.BtnExcel.Location = New System.Drawing.Point(22, 230)
        Me.BtnExcel.Name = "BtnExcel"
        Me.BtnExcel.Size = New System.Drawing.Size(205, 99)
        Me.BtnExcel.TabIndex = 69
        Me.BtnExcel.Text = "Automation"
        Me.BtnExcel.UseVisualStyleBackColor = False
        '
        'BtnSuivant
        '
        Me.BtnSuivant.BackColor = System.Drawing.SystemColors.Highlight
        Me.BtnSuivant.Font = New System.Drawing.Font("Century Gothic", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSuivant.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.BtnSuivant.ImageAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.BtnSuivant.Location = New System.Drawing.Point(129, 599)
        Me.BtnSuivant.Name = "BtnSuivant"
        Me.BtnSuivant.Size = New System.Drawing.Size(94, 82)
        Me.BtnSuivant.TabIndex = 68
        Me.BtnSuivant.Text = "►"
        Me.BtnSuivant.UseVisualStyleBackColor = False
        '
        'BtnPrecedent
        '
        Me.BtnPrecedent.BackColor = System.Drawing.SystemColors.Highlight
        Me.BtnPrecedent.Font = New System.Drawing.Font("Century Gothic", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnPrecedent.ForeColor = System.Drawing.SystemColors.Control
        Me.BtnPrecedent.ImageAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.BtnPrecedent.Location = New System.Drawing.Point(22, 599)
        Me.BtnPrecedent.Name = "BtnPrecedent"
        Me.BtnPrecedent.Size = New System.Drawing.Size(93, 82)
        Me.BtnPrecedent.TabIndex = 67
        Me.BtnPrecedent.Text = "◄"
        Me.BtnPrecedent.UseVisualStyleBackColor = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Century Gothic", 13.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.MenuText
        Me.Label5.Location = New System.Drawing.Point(82, 593)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(84, 30)
        Me.Label5.TabIndex = 63
        Me.Label5.Text = "Stock"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Century Gothic", 13.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.MenuText
        Me.Label4.Location = New System.Drawing.Point(105, 496)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(61, 30)
        Me.Label4.TabIndex = 62
        Me.Label4.Text = "TVA"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Century Gothic", 13.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.MenuText
        Me.Label3.Location = New System.Drawing.Point(23, 399)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(159, 30)
        Me.Label3.TabIndex = 61
        Me.Label3.Text = "Prix Unitaire"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Century Gothic", 13.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.MenuText
        Me.Label2.Location = New System.Drawing.Point(23, 299)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(162, 30)
        Me.Label2.TabIndex = 60
        Me.Label2.Text = "Designation"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Century Gothic", 13.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.MenuText
        Me.Label1.Location = New System.Drawing.Point(10, 197)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(178, 30)
        Me.Label1.TabIndex = 59
        Me.Label1.Text = "Code Produit"
        '
        'TxtStock
        '
        Me.TxtStock.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ProduitBindingSource, "Stock", True))
        Me.TxtStock.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtStock.Location = New System.Drawing.Point(203, 586)
        Me.TxtStock.Name = "TxtStock"
        Me.TxtStock.Size = New System.Drawing.Size(513, 42)
        Me.TxtStock.TabIndex = 56
        '
        'ProduitBindingSource
        '
        Me.ProduitBindingSource.DataMember = "Produit"
        Me.ProduitBindingSource.DataSource = Me.FournDataSet
        '
        'FournDataSet
        '
        Me.FournDataSet.DataSetName = "FournDataSet"
        Me.FournDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TxtTVA
        '
        Me.TxtTVA.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ProduitBindingSource, "TVA", True))
        Me.TxtTVA.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtTVA.Location = New System.Drawing.Point(203, 489)
        Me.TxtTVA.Name = "TxtTVA"
        Me.TxtTVA.Size = New System.Drawing.Size(513, 42)
        Me.TxtTVA.TabIndex = 55
        '
        'TxtPrix
        '
        Me.TxtPrix.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ProduitBindingSource, "PrixUnitaire", True))
        Me.TxtPrix.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtPrix.Location = New System.Drawing.Point(203, 391)
        Me.TxtPrix.Name = "TxtPrix"
        Me.TxtPrix.Size = New System.Drawing.Size(513, 42)
        Me.TxtPrix.TabIndex = 54
        '
        'TxtDesignation
        '
        Me.TxtDesignation.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ProduitBindingSource, "Designation", True))
        Me.TxtDesignation.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtDesignation.Location = New System.Drawing.Point(203, 294)
        Me.TxtDesignation.Name = "TxtDesignation"
        Me.TxtDesignation.Size = New System.Drawing.Size(513, 42)
        Me.TxtDesignation.TabIndex = 53
        '
        'TxtCode
        '
        Me.TxtCode.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ProduitBindingSource, "CodeProduit", True))
        Me.TxtCode.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtCode.Location = New System.Drawing.Point(203, 190)
        Me.TxtCode.Name = "TxtCode"
        Me.TxtCode.Size = New System.Drawing.Size(513, 42)
        Me.TxtCode.TabIndex = 52
        '
        'ProduitTableAdapter
        '
        Me.ProduitTableAdapter.ClearBeforeFill = True
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.TxtCode)
        Me.Panel1.Controls.Add(Me.TxtDesignation)
        Me.Panel1.Controls.Add(Me.TxtPrix)
        Me.Panel1.Controls.Add(Me.TxtTVA)
        Me.Panel1.Controls.Add(Me.TxtStock)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Location = New System.Drawing.Point(2, 27)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(740, 702)
        Me.Panel1.TabIndex = 77
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.SystemColors.Highlight
        Me.Button1.Font = New System.Drawing.Font("Century Gothic", 28.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.Button1.Location = New System.Drawing.Point(203, 59)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(513, 80)
        Me.Button1.TabIndex = 55
        Me.Button1.Text = "PRODUITS"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.SystemColors.HighlightText
        Me.Panel3.Controls.Add(Me.Label15)
        Me.Panel3.Controls.Add(Me.BtnAjouter1)
        Me.Panel3.Controls.Add(Me.BtnExcel)
        Me.Panel3.Controls.Add(Me.BtnRecherche)
        Me.Panel3.Controls.Add(Me.BtnEffacer)
        Me.Panel3.Controls.Add(Me.BtnModifier)
        Me.Panel3.Controls.Add(Me.BtnSupprimer)
        Me.Panel3.Controls.Add(Me.BtnPrecedent)
        Me.Panel3.Controls.Add(Me.BtnSuivant)
        Me.Panel3.Location = New System.Drawing.Point(740, 27)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(239, 702)
        Me.Panel3.TabIndex = 76
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Century Gothic", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.SystemColors.Highlight
        Me.Label15.Location = New System.Drawing.Point(44, 19)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(157, 43)
        Me.Label15.TabIndex = 52
        Me.Label15.Text = "Boutons"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.SystemColors.Highlight
        Me.MenuStrip1.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TsFournisseur, Me.TsClient, Me.TsCommande, Me.TsProduit, Me.TsFacturation})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(978, 31)
        Me.MenuStrip1.TabIndex = 78
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'TsFournisseur
        '
        Me.TsFournisseur.ForeColor = System.Drawing.SystemColors.Window
        Me.TsFournisseur.Name = "TsFournisseur"
        Me.TsFournisseur.Size = New System.Drawing.Size(129, 27)
        Me.TsFournisseur.Text = "Fournisseur"
        '
        'TsClient
        '
        Me.TsClient.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TsClient.ForeColor = System.Drawing.SystemColors.Window
        Me.TsClient.Name = "TsClient"
        Me.TsClient.Size = New System.Drawing.Size(79, 27)
        Me.TsClient.Text = "Client"
        '
        'TsCommande
        '
        Me.TsCommande.ForeColor = System.Drawing.SystemColors.Window
        Me.TsCommande.Name = "TsCommande"
        Me.TsCommande.Size = New System.Drawing.Size(140, 27)
        Me.TsCommande.Text = "Commande"
        '
        'TsProduit
        '
        Me.TsProduit.ForeColor = System.Drawing.SystemColors.Window
        Me.TsProduit.Name = "TsProduit"
        Me.TsProduit.Size = New System.Drawing.Size(88, 27)
        Me.TsProduit.Text = "Produit"
        '
        'TsFacturation
        '
        Me.TsFacturation.ForeColor = System.Drawing.SystemColors.Window
        Me.TsFacturation.Name = "TsFacturation"
        Me.TsFacturation.Size = New System.Drawing.Size(131, 27)
        Me.TsFacturation.Text = "Facturation"
        '
        'Produit
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(978, 729)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel3)
        Me.Name = "Produit"
        Me.Text = "Form7"
        CType(Me.ProduitBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FournDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents BtnModifier As System.Windows.Forms.Button
    Friend WithEvents BtnAjouter1 As System.Windows.Forms.Button
    Friend WithEvents BtnSupprimer As System.Windows.Forms.Button
    Friend WithEvents BtnEffacer As System.Windows.Forms.Button
    Friend WithEvents BtnRecherche As System.Windows.Forms.Button
    Friend WithEvents BtnExcel As System.Windows.Forms.Button
    Friend WithEvents BtnSuivant As System.Windows.Forms.Button
    Friend WithEvents BtnPrecedent As System.Windows.Forms.Button
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TxtStock As System.Windows.Forms.TextBox
    Friend WithEvents TxtTVA As System.Windows.Forms.TextBox
    Friend WithEvents TxtPrix As System.Windows.Forms.TextBox
    Friend WithEvents TxtDesignation As System.Windows.Forms.TextBox
    Friend WithEvents TxtCode As System.Windows.Forms.TextBox
    Friend WithEvents FournDataSet As WindowsApplication1.FournDataSet
    Friend WithEvents ProduitBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents ProduitTableAdapter As WindowsApplication1.FournDataSetTableAdapters.ProduitTableAdapter
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents TsFournisseur As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TsClient As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TsCommande As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TsProduit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TsFacturation As System.Windows.Forms.ToolStripMenuItem
End Class
