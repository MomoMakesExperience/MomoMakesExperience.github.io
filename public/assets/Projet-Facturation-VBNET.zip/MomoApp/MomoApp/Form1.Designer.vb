﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.NumCommandeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.IdClientDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DateCommandeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CommandeRegleDataGridViewCheckBoxColumn = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.CommandeBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.FournDataSet = New WindowsApplication1.FournDataSet()
        Me.CommandeTableAdapter = New WindowsApplication1.FournDataSetTableAdapters.CommandeTableAdapter()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.MamadouToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UGBToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Panel1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CommandeBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FournDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Panel1.Controls.Add(Me.DataGridView1)
        Me.Panel1.Controls.Add(Me.MenuStrip1)
        Me.Panel1.Location = New System.Drawing.Point(-6, 4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1330, 823)
        Me.Panel1.TabIndex = 0
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.NumCommandeDataGridViewTextBoxColumn, Me.IdClientDataGridViewTextBoxColumn, Me.DateCommandeDataGridViewTextBoxColumn, Me.CommandeRegleDataGridViewCheckBoxColumn})
        Me.DataGridView1.DataSource = Me.CommandeBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(503, 143)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowTemplate.Height = 28
        Me.DataGridView1.Size = New System.Drawing.Size(603, 343)
        Me.DataGridView1.TabIndex = 0
        '
        'NumCommandeDataGridViewTextBoxColumn
        '
        Me.NumCommandeDataGridViewTextBoxColumn.DataPropertyName = "NumCommande"
        Me.NumCommandeDataGridViewTextBoxColumn.HeaderText = "NumCommande"
        Me.NumCommandeDataGridViewTextBoxColumn.Name = "NumCommandeDataGridViewTextBoxColumn"
        '
        'IdClientDataGridViewTextBoxColumn
        '
        Me.IdClientDataGridViewTextBoxColumn.DataPropertyName = "IdClient"
        Me.IdClientDataGridViewTextBoxColumn.HeaderText = "IdClient"
        Me.IdClientDataGridViewTextBoxColumn.Name = "IdClientDataGridViewTextBoxColumn"
        '
        'DateCommandeDataGridViewTextBoxColumn
        '
        Me.DateCommandeDataGridViewTextBoxColumn.DataPropertyName = "DateCommande"
        Me.DateCommandeDataGridViewTextBoxColumn.HeaderText = "DateCommande"
        Me.DateCommandeDataGridViewTextBoxColumn.Name = "DateCommandeDataGridViewTextBoxColumn"
        '
        'CommandeRegleDataGridViewCheckBoxColumn
        '
        Me.CommandeRegleDataGridViewCheckBoxColumn.DataPropertyName = "CommandeRegle"
        Me.CommandeRegleDataGridViewCheckBoxColumn.HeaderText = "CommandeRegle"
        Me.CommandeRegleDataGridViewCheckBoxColumn.Name = "CommandeRegleDataGridViewCheckBoxColumn"
        '
        'CommandeBindingSource
        '
        Me.CommandeBindingSource.DataMember = "Commande"
        Me.CommandeBindingSource.DataSource = Me.FournDataSet
        '
        'FournDataSet
        '
        Me.FournDataSet.DataSetName = "FournDataSet"
        Me.FournDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'CommandeTableAdapter
        '
        Me.CommandeTableAdapter.ClearBeforeFill = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MamadouToolStripMenuItem, Me.UGBToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1330, 33)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'MamadouToolStripMenuItem
        '
        Me.MamadouToolStripMenuItem.Name = "MamadouToolStripMenuItem"
        Me.MamadouToolStripMenuItem.Size = New System.Drawing.Size(106, 29)
        Me.MamadouToolStripMenuItem.Text = "Mamadou"
        '
        'UGBToolStripMenuItem
        '
        Me.UGBToolStripMenuItem.Name = "UGBToolStripMenuItem"
        Me.UGBToolStripMenuItem.Size = New System.Drawing.Size(58, 29)
        Me.UGBToolStripMenuItem.Text = "UGB"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1330, 827)
        Me.Controls.Add(Me.Panel1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CommandeBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FournDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents FournDataSet As WindowsApplication1.FournDataSet
    Friend WithEvents CommandeBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents CommandeTableAdapter As WindowsApplication1.FournDataSetTableAdapters.CommandeTableAdapter
    Friend WithEvents NumCommandeDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents IdClientDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DateCommandeDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CommandeRegleDataGridViewCheckBoxColumn As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents MamadouToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UGBToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
