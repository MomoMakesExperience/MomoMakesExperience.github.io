﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PConnexion
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(PConnexion))
        Me.BtnAnnuler = New System.Windows.Forms.Button()
        Me.BtnValider = New System.Windows.Forms.Button()
        Me.Mdp = New System.Windows.Forms.Label()
        Me.LblLogin = New System.Windows.Forms.Label()
        Me.TxtMdp = New System.Windows.Forms.TextBox()
        Me.TxtLogin = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'BtnAnnuler
        '
        Me.BtnAnnuler.BackColor = System.Drawing.SystemColors.Highlight
        Me.BtnAnnuler.Font = New System.Drawing.Font("Century Gothic", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnAnnuler.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.BtnAnnuler.Location = New System.Drawing.Point(295, 430)
        Me.BtnAnnuler.Name = "BtnAnnuler"
        Me.BtnAnnuler.Size = New System.Drawing.Size(216, 56)
        Me.BtnAnnuler.TabIndex = 13
        Me.BtnAnnuler.Text = "Annuler"
        Me.BtnAnnuler.UseVisualStyleBackColor = False
        '
        'BtnValider
        '
        Me.BtnValider.BackColor = System.Drawing.SystemColors.Highlight
        Me.BtnValider.Font = New System.Drawing.Font("Century Gothic", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnValider.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.BtnValider.Location = New System.Drawing.Point(67, 430)
        Me.BtnValider.Name = "BtnValider"
        Me.BtnValider.Size = New System.Drawing.Size(216, 56)
        Me.BtnValider.TabIndex = 12
        Me.BtnValider.Text = "Valider"
        Me.BtnValider.UseVisualStyleBackColor = False
        '
        'Mdp
        '
        Me.Mdp.AutoSize = True
        Me.Mdp.Font = New System.Drawing.Font("Century Gothic", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Mdp.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Mdp.Location = New System.Drawing.Point(68, 307)
        Me.Mdp.Name = "Mdp"
        Me.Mdp.Size = New System.Drawing.Size(225, 38)
        Me.Mdp.TabIndex = 10
        Me.Mdp.Text = "Mot de passe"
        '
        'LblLogin
        '
        Me.LblLogin.AutoSize = True
        Me.LblLogin.Font = New System.Drawing.Font("Century Gothic", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLogin.ForeColor = System.Drawing.SystemColors.ControlText
        Me.LblLogin.Location = New System.Drawing.Point(68, 199)
        Me.LblLogin.Name = "LblLogin"
        Me.LblLogin.Size = New System.Drawing.Size(99, 38)
        Me.LblLogin.TabIndex = 9
        Me.LblLogin.Text = "Login"
        '
        'TxtMdp
        '
        Me.TxtMdp.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtMdp.Location = New System.Drawing.Point(67, 361)
        Me.TxtMdp.Name = "TxtMdp"
        Me.TxtMdp.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.TxtMdp.Size = New System.Drawing.Size(444, 42)
        Me.TxtMdp.TabIndex = 8
        '
        'TxtLogin
        '
        Me.TxtLogin.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtLogin.Location = New System.Drawing.Point(67, 250)
        Me.TxtLogin.Name = "TxtLogin"
        Me.TxtLogin.Size = New System.Drawing.Size(444, 42)
        Me.TxtLogin.TabIndex = 7
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Controls.Add(Me.LblLogin)
        Me.Panel1.Controls.Add(Me.BtnAnnuler)
        Me.Panel1.Controls.Add(Me.TxtLogin)
        Me.Panel1.Controls.Add(Me.BtnValider)
        Me.Panel1.Controls.Add(Me.TxtMdp)
        Me.Panel1.Controls.Add(Me.Mdp)
        Me.Panel1.Location = New System.Drawing.Point(0, 2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(593, 557)
        Me.Panel1.TabIndex = 14
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.SystemColors.Highlight
        Me.Button1.Font = New System.Drawing.Font("Century Gothic", 28.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.Button1.Location = New System.Drawing.Point(67, 53)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(450, 120)
        Me.Button1.TabIndex = 14
        Me.Button1.Text = "CONNEXION"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'PConnexion
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(589, 554)
        Me.Controls.Add(Me.Panel1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "PConnexion"
        Me.Text = "Form4"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents BtnAnnuler As System.Windows.Forms.Button
    Friend WithEvents BtnValider As System.Windows.Forms.Button
    Friend WithEvents Mdp As System.Windows.Forms.Label
    Friend WithEvents LblLogin As System.Windows.Forms.Label
    Friend WithEvents TxtMdp As System.Windows.Forms.TextBox
    Friend WithEvents TxtLogin As System.Windows.Forms.TextBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Button1 As System.Windows.Forms.Button
End Class
