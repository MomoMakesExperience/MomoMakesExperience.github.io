﻿'Inclusion de Références'
Imports System
Imports System.Data
Imports System.Data.OleDb
Imports Microsoft.Office.Interop

Public Class PCommande

    'Declaration de variables'
    Public cnn As OleDbConnection 'connexion a la Base de données'
    Public cmd As OleDbCommand 'Pour les requetes SQL'
    Public dtr As OleDbDataReader 'Lecteur de données'
    Private strSQL, strConn As String
    Public dta As OleDbDataAdapter 'Pour recupèrer les données modifier inserer entre la base et Dataset'
    Private cmb As OleDbCommandBuilder

    Private Sub TsFournisseur_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TsFournisseur.Click
        PFournisseur.Show()
    End Sub

    Private Sub TsClient_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TsClient.Click
        PClient.Show()
    End Sub

    Private Sub TsCommande_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TsCommande.Click
        Me.Show()
    End Sub

    Private Sub TsProduit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TsProduit.Click
        Produit.Show()
    End Sub

    Private Sub TsFacturation_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TsFacturation.Click
        Facturation.Show()
    End Sub

    Private Sub Form8_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: cette ligne de code charge les données dans la table 'FournDataSet.Commande'. Vous pouvez la déplacer ou la supprimer selon vos besoins.
        Me.CommandeTableAdapter.Fill(Me.FournDataSet.Commande)

    End Sub

    'Procédure pour voir le précédent'
    Private Sub BtnPrecedent_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnPrecedent.Click
        CommandeBindingSource.MovePrevious()
    End Sub

    'Procédure pour voir le suivant'
    Private Sub BtnSuivant_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnSuivant.Click
        CommandeBindingSource.MoveNext()
    End Sub

    'On veut faire une extraction de données'
    Private Sub BtnRecherche_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim cnn As New OleDbConnection("Provider = Microsoft.Jet.OleDb.4.0; Data Source = " & Application.StartupPath & "\Fournisseur.mdb")
        'Si on a une zone de texte on met les apostrophes sinon on ne met pas'
        Dim cmd As New OleDbCommand("SELECT * FROM Commande WHERE NumCommande = '" & TxtCommande.Text & "'", cnn)
        'Ouverture de la connection'
        cnn.Open()
        'Execution de la commande'
        Dim dtr As OleDbDataReader = cmd.ExecuteReader
        'Condition de Lecture'
        If dtr.Read() Then
            MessageBox.Show("Il existe une commande sur ce numero")
            'On rempli les infos de la base dans le formulaire'
            TxtCommande.Text = dtr(0).ToString
            TxtID.Text = dtr(1).ToString
            TxtDate.Text = dtr(2).ToString
            TxtEtat.Text = dtr(3).ToString
        Else
            'Message d erreurs'
            MessageBox.Show("Il existe aucune commande sur ce numero")
            TxtCommande.Clear()
            TxtCommande.Focus()
        End If
    End Sub

    Private Sub BtnEffacer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnEffacer.Click

        Me.TxtCommande.ResetText()
        Me.TxtID.ResetText()
        Me.TxtDate.ResetText()
        Me.TxtEtat.ResetText()

    End Sub

    Private Sub BtnAjouter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnAjouter.Click
        'Connexion a la base je lui donne le nom de la base et la machine va la trouver'
        Dim cnn As New OleDbConnection("Provider = Microsoft.Jet.OleDb.4.0; Data Source = " & Application.StartupPath & "\Fournisseur.mdb")
        'Si on a une zone de texte on met les apostrophes sinon on ne met pas'
        Dim cmd As New OleDbCommand("SELECT * FROM Commande WHERE NumCommande = '" & TxtCommande.Text & "'", cnn)
        'Ouverture de la connection'
        cnn.Open()
        'Lecture des données'
        Dim dtr As OleDbDataReader = cmd.ExecuteReader
        'Préparation des données à recupèrer'
        Dim dta As New OleDbDataAdapter(cmd)
        'Stockage des données en mémoire'
        Dim dts As New DataSet
        If dtr.Read() Then
            MessageBox.Show("Cette commande existe déjà !")
            'Effacement des zones de textes et Renvoie du curseur au niveau de la zone de texte du ID'
            TxtCommande.Clear()
            TxtCommande.Focus()
            TxtID.Clear()
            TxtDate.Clear()
            TxtEtat.Clear()
        Else
            dtr.Close()
            'C'est une methode qui nous permet de remplir notre DataSet oubien notre Table : Fournisseur'
            dta.Fill(dts, "Commande")
            'Ajout d une nouvelle ligne dans ma table Fournisseur'
            dts.Tables("Commande").Rows.Add(New Object() {TxtCommande.Text, TxtID.Text, TxtDate.Text, TxtEtat.Text})
            'Nous permet de créer des requetes SQL (INSERT, UPDATE, DELETE...) et complete le dataAdapter la on a deja la requete donc il modifie juste la table'
            'Ne pas oublier que le DataAdapter dta a la valeur de cmd '
            Dim cmb As New OleDbCommandBuilder(dta)
            dta.Update(dts, "Commande")
            MessageBox.Show("Commande Ajoutée !")
            TxtCommande.Clear()
            TxtCommande.Focus()
            TxtID.Clear()
            TxtDate.Clear()
            TxtEtat.Clear()

            'Fermeture de la connexion'
            cnn.Close()
        End If
    End Sub

    'Procédure pour supprimer une commande de la base de données'
    Private Sub BtnSupprimer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnSupprimer.Click
        'Construction de la chaine de connexion vers la base de données Access'
        strConn = "Provider = Microsoft.Jet.OleDb.4.0; Data Source = " & Application.StartupPath & "\Fournisseur.mdb"

        'Création et ouverture de l'objet de connexion'
        cnn = New OleDbConnection()
        cnn.ConnectionString = strConn
        cnn.Open()
        'Création de l'objet commande'
        cmd = cnn.CreateCommand()
        cmd.CommandType = CommandType.Text

        'Déclaration d'une variable pour récupérer la réponse de l'utilisateur'
        Dim reponse As MsgBoxResult

        'CORRECTION : Requête ciblée sur la table Commande avec NumCommande'
        strSQL = "DELETE FROM Commande WHERE NumCommande = '" & TxtCommande.Text & "'"

        'Affichage de la boîte de dialogue de confirmation'
        reponse = MsgBox("Voulez-vous vraiment supprimer cette commande ?", vbYesNo, "Suppression")

        'Si l'utilisateur clique sur Oui'
        If reponse = vbYes Then
            'Association et exécution de la requête SQL'
            cmd.CommandText = strSQL
            cmd.ExecuteNonQuery()
            MsgBox("Suppression effectuée !", , "Suppression")
        Else
            'Affichage d'un message indiquant que la suppression a été annulée'
            MsgBox("Suppression non effectuée !")
        End If

        'Effacement du contenu des zones de texte'
        Me.TxtCommande.ResetText()
        Me.TxtID.ResetText()
        Me.TxtDate.ResetText()
        Me.TxtEtat.ResetText()

        'Fermeture de la connexion'
        cnn.Close()
    End Sub

    Private Sub BtnModifier_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnModifier.Click
        Dim strConn As String = "Provider = Microsoft.Jet.OleDb.4.0; Data Source = " & Application.StartupPath & "\Fournisseur.mdb"
        Dim strSQL As String
        Try
            Using cnn As New OleDb.OleDbConnection(strConn)
                cnn.Open()
                Dim reponse As MsgBoxResult
                reponse = MsgBox("Voulez vous réellement modifier l'enregistrement ?", MsgBoxStyle.YesNo, "Modification")

                If reponse = MsgBoxResult.Yes Then
                    strSQL = "UPDATE Commande SET IdClient = ?, DateCommande = ?, CommandeRegle = ? WHERE NumCommande = ?"
                    Using cmd As New OleDb.OleDbCommand(strSQL, cnn)

                        ' 1. IdClient (Texte)
                        cmd.Parameters.AddWithValue("@IdClient", TxtID.Text)

                        ' 2. DateCommande (Conversion en vraie Date obligatoire pour Access)
                        Dim dateCmd As Date
                        If DateTryPattern(TxtDate.Text, dateCmd) Then
                            cmd.Parameters.AddWithValue("@DateCommande", dateCmd)
                        Else
                            ' Si le texte n'est pas une date valide, on tente CDate ou on lève une alerte
                            cmd.Parameters.AddWithValue("@DateCommande", Convert.ToDateTime(TxtDate.Text))
                        End If

                        ' 3. CommandeRegle (Conversion en Booléen pour le type Oui/Non de Access)
                        ' Gère si l'utilisateur écrit "True", "1", "Oui" ou si TxtEtat est lié à une checkbox
                        Dim etatBool As Boolean = False
                        If TxtEtat.Text.ToLower() = "true" OrElse TxtEtat.Text = "1" OrElse TxtEtat.Text.ToLower() = "oui" Then
                            etatBool = True
                        End If
                        cmd.Parameters.AddWithValue("@CommandeRegle", etatBool)

                        ' 4. NumCommande (Critère WHERE - Texte)
                        cmd.Parameters.AddWithValue("@NumCommande", TxtCommande.Text)

                        If cmd.ExecuteNonQuery() > 0 Then
                            MessageBox.Show("Modification effectuée !", "Modification")
                        Else
                            MessageBox.Show("Aucun enregistrement trouvé !", "Information")
                        End If

                    End Using

                    ' Nettoyage des champs après modification réussie
                    TxtCommande.Clear()
                    TxtID.Clear()
                    TxtDate.Clear()
                    TxtEtat.Clear()
                End If
            End Using
        Catch ex As Exception
            MessageBox.Show("ERREUR !" & ex.Message)
        End Try
    End Sub

    ' Petite fonction utilitaire à placer dans ton formulaire pour valider le format de date
    Private Function DateTryPattern(ByVal text As String, ByRef dateResult As Date) As Boolean
        Return Date.TryParse(text, dateResult)
    End Function

    Private Sub BtnRecherche_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnRecherche.Click
        Dim cnn As New OleDbConnection("Provider = Microsoft.Jet.OleDb.4.0; Data Source = " & Application.StartupPath & "\Fournisseur.mdb")
        'Si on a une zone de texte on met les apostrophes sinon on ne met pas'
        Dim cmd As New OleDbCommand("SELECT * FROM Commande WHERE NumCommande = '" & TxtCommande.Text & "'", cnn)
        'Ouverture de la connection'
        cnn.Open()
        'Execution de la commande'
        Dim dtr As OleDbDataReader = cmd.ExecuteReader
        'Condition de Lecture'
        If dtr.Read() Then
            MessageBox.Show("Il existe un fournisseur sur ce ID")
            'On rempli les infos de la base dans le formulaire'
            TxtCommande.Text = dtr(0).ToString
            TxtID.Text = dtr(1).ToString
            TxtDate.Text = dtr(2).ToString
            TxtEtat.Text = dtr(3).ToString
        Else
            'Message d erreurs'
            MessageBox.Show("Il existe aucune commande sur ce numero")
            TxtCommande.Clear()
            TxtCommande.Focus()
        End If
    End Sub
End Class